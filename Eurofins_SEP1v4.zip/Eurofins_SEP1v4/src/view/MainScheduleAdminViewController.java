package view;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle; 
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import model.MyDate;


public class MainScheduleAdminViewController
{
   private GUI gui;
   private Scene scene;
   public MyDate first;
   @FXML public Label firstDay;
   @FXML public Label secondDay;
   @FXML public Label thirdDay;
   @FXML public Label fourthDay;
   @FXML public Label fifthDay;
   @FXML public Label sixthDay;
   @FXML public Label seventhDay;

   @FXML
   void initialize() {
   }

   public MainScheduleAdminViewController(GUI gui) throws IOException {
      this.gui=gui;
      FXMLLoader loader = new FXMLLoader();
      loader.setLocation(getClass().getResource("MainScheduleAdmin.fxml"));
      loader.setController(this);

      Parent root = loader.load();
      this.scene = new Scene(root);
   }


   public void signOutbuttonPressed()  {
      gui.displayWindowLoginViewController();
   }
   
   public void AssignButtonPressed() {
      gui.displayAssignTaskViewController();
   }
   
   public void manageAnalysisbuttonPressed()  {
      gui.displayManageAnalysisViewController();
   }
   
   public void manageWorkersbuttonPressed()  {
      gui.displayManageWorkersViewController();
   }

   public void SearchbuttonPressed()  {
      gui.displaySearchViewController();
   }

   public Scene getScene(){
      return scene;
   }
}
