package view;

import java.io.IOException;
import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Analysis;
import model.Worker;
import model.WorkerList;

public class AssignTaskViewController
{
   @FXML private TableView tableViewWorker;
   @FXML private TableView tableViewAnalysis;
   @FXML private TableColumn idColumn;
   @FXML private TableColumn nameColumn;
   @FXML private TableColumn aNameColumn;
   private GUI gui;
   private Scene scene;
   private ArrayList<Worker> workerList;
   private ArrayList<Analysis> analysisList;

   public AssignTaskViewController(GUI gui) throws IOException {
      this.gui = gui;
      FXMLLoader loader = new FXMLLoader();
      loader.setLocation(getClass().getResource("AssignTask.fxml"));
      loader.setController(this);
      Parent root = loader.load();
      this.scene = new Scene(root);      
  }
   
   @FXML void initialize() {
      tableViewWorker.setRowFactory(tableView -> {
         TableRow<Worker> newRow = new TableRow<>();
         return newRow;
     });

     idColumn.setCellValueFactory(new PropertyValueFactory<Worker, String>("iDnr"));
     nameColumn.setCellValueFactory(new PropertyValueFactory<Worker, String>("fullName"));
     
     tableViewAnalysis.setRowFactory(tableView -> {
        TableRow<Analysis> newRow1 = new TableRow<>();
        return newRow1;
    });

    aNameColumn.setCellValueFactory(new PropertyValueFactory<Analysis, String>("name"));
      
   }
   
   public Scene getScene(){
      return scene;
   }
   
   public void ReturnButtonPressed() {
      gui.displayMainScheduleAdminViewController();
   }
   
   public void updateItems(){
      this.workerList = gui.getController().getModel().getAllWorkers();
      this.analysisList = gui.getController().getModel().getAllAnalysis();
      tableViewAnalysis.setItems(FXCollections.observableList(analysisList));
      tableViewWorker.setItems(FXCollections.observableList(workerList));
      tableViewWorker.refresh();
      tableViewAnalysis.refresh();
  }

}
