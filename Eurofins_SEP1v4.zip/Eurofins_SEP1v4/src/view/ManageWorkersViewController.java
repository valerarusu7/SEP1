package view;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

public class ManageWorkersViewController
{
   private GUI gui;
   private Scene scene;
   @FXML private ResourceBundle resources;
   @FXML private URL location;
   @FXML void initialize() {
   }

   public ManageWorkersViewController(GUI gui) throws IOException {
      this.gui=gui;
      FXMLLoader loader = new FXMLLoader();
      loader.setLocation(getClass().getResource("Manage-Workers.fxml"));
      loader.setController(this);

      Parent root = loader.load();
      this.scene = new Scene(root);
   }

   public void AddWorkerssbuttonPressed()  {
      gui.displayAddWorkerViewController();
   }
   
   public void RemoveWorkersbuttonPressed()  {
      gui.displayRemoveWorkerViewController();
   }

   public void WorkerListbuttonPressed() {
      gui.displayWorkerListViewController();
   }

   public void ReturnbuttonPressed()  {
      gui.displayMainScheduleAdminViewController();
   }


   public Scene getScene(){
      return scene;
   }
}
