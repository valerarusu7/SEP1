package view;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

public class SearchViewController
{
   private GUI gui;
   private Scene scene;
   @FXML private ResourceBundle resources;
   @FXML private URL location;
   @FXML void initialize() {
   }

   public SearchViewController(GUI gui) throws IOException {
      this.gui=gui;
      FXMLLoader loader = new FXMLLoader();
      loader.setLocation(getClass().getResource("Search.fxml"));
      loader.setController(this);

      Parent root = loader.load();
      this.scene = new Scene(root);
   }

   public void ReturnbuttonPressed() {
      gui.displayMainScheduleAdminViewController();
   }

   public Scene getScene(){
      return scene;
   }

}
