package view;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import model.Worker;
import java.io.IOException;

public class WorkerProfileViewController {
    @FXML private Label fullNameWorker;
    @FXML private Label IDworker;
    private GUI gui;
    private Scene scene;
    private Worker worker;

    public WorkerProfileViewController(GUI gui) throws IOException {
        this.gui = gui;
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("Worker_Profile.fxml"));
        loader.setController(this);
        Parent root = loader.load();
        this.scene = new Scene(root);
    }

    @FXML private void initialize() {
    }

    public void setNameData(String name) {
        fullNameWorker.setText(worker.getFullName());
    }

    public void setIdData(String id) {
        IDworker.setText(worker.getIDnr());
    }

    public Scene getScene(){
        return scene;
    }
}

