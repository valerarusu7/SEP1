package view;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import model.MyDate;

import java.io.IOException;

public class WindowLoginViewController
{
   private GUI gui;
   private Scene scene;
   @FXML
   private PasswordField passwordField;
   @FXML
   private TextField usernameField;
   @FXML
   private Label lblStatus;

   public WindowLoginViewController(GUI gui) throws IOException
   {
      this.gui = gui;
      FXMLLoader loader = new FXMLLoader();
      loader.setLocation(getClass().getResource("WindowLogin.fxml"));
      loader.setController(this);

      Parent root = loader.load();
      this.scene = new Scene(root);
   }

   @FXML
   void loginButtonPressed() throws ClassNotFoundException
   {
      if (passwordField.getText().equals("123")
            && usernameField.getText().equals("worker"))
      {
         gui.displayMainScheduleWorkerViewController();
         gui.displayMainScheduleWorkerViewController();
         gui.getMainScheduleWorkerViewController().second = new MyDate();
         gui.getMainScheduleWorkerViewController().firstDay
               .setText(gui.getMainScheduleWorkerViewController().second.toString());
         gui.getMainScheduleWorkerViewController().second.stepForward(1);
         gui.getMainScheduleWorkerViewController().secondDay
               .setText(gui.getMainScheduleWorkerViewController().second.toString());
         gui.getMainScheduleWorkerViewController().second.stepForward(1);
         gui.getMainScheduleWorkerViewController().thirdDay
               .setText(gui.getMainScheduleWorkerViewController().second.toString());
         gui.getMainScheduleWorkerViewController().second.stepForward(1);
         gui.getMainScheduleWorkerViewController().fourthDay
               .setText(gui.getMainScheduleWorkerViewController().second.toString());
         gui.getMainScheduleWorkerViewController().second.stepForward(1);
         gui.getMainScheduleWorkerViewController().fifthDay
               .setText(gui.getMainScheduleWorkerViewController().second.toString());
         gui.getMainScheduleWorkerViewController().second.stepForward(1);
         gui.getMainScheduleWorkerViewController().sixthDay
               .setText(gui.getMainScheduleWorkerViewController().second.toString());
         gui.getMainScheduleWorkerViewController().second.stepForward(1);
         gui.getMainScheduleWorkerViewController().seventhDay
               .setText(gui.getMainScheduleWorkerViewController().second.toString());
         gui.getMainScheduleWorkerViewController().second.stepForward(1);
      }
      else if
         (passwordField.getText().equals("admin1")
               && usernameField.getText().equals("teamleader1"))
         {
            gui.displayMainScheduleAdminViewController();
            gui.getMainScheduleAdminViewController().first = new MyDate();
            gui.getMainScheduleAdminViewController().firstDay
                  .setText(gui.getMainScheduleAdminViewController().first.toString());
            gui.getMainScheduleAdminViewController().first.stepForward(1);
            gui.getMainScheduleAdminViewController().secondDay
                  .setText(gui.getMainScheduleAdminViewController().first.toString());
            gui.getMainScheduleAdminViewController().first.stepForward(1);
            gui.getMainScheduleAdminViewController().thirdDay
                  .setText(gui.getMainScheduleAdminViewController().first.toString());
            gui.getMainScheduleAdminViewController().first.stepForward(1);
            gui.getMainScheduleAdminViewController().fourthDay
                  .setText(gui.getMainScheduleAdminViewController().first.toString());
            gui.getMainScheduleAdminViewController().first.stepForward(1);
            gui.getMainScheduleAdminViewController().fifthDay
                  .setText(gui.getMainScheduleAdminViewController().first.toString());
            gui.getMainScheduleAdminViewController().first.stepForward(1);
            gui.getMainScheduleAdminViewController().sixthDay
                  .setText(gui.getMainScheduleAdminViewController().first.toString());
            gui.getMainScheduleAdminViewController().first.stepForward(1);
            gui.getMainScheduleAdminViewController().seventhDay
                  .setText(gui.getMainScheduleAdminViewController().first.toString());
            gui.getMainScheduleAdminViewController().first.stepForward(1);
         }
      else
      {
         lblStatus.setText("Login Failed");
         usernameField.clear();
         passwordField.clear();

      }
   }

   public Scene getScene()
   {
      return scene;
   }

}
