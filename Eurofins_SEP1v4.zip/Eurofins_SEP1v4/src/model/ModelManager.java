package model;

import java.io.IOException;
import java.util.ArrayList;

public class ModelManager implements Model {
    private WorkerList workerList;
    private AnalysisList analysisList;
    private FileManager Workers;
    private FileManager Analysis;
    private FileManager TemplateS;
    private FileManager TemplateL;
    private FileManager ScheduleM;

    public ModelManager() throws ClassNotFoundException {
      this.Workers = new FileManager("Workers.bin");
      this.Analysis = new FileManager("Analysis.bin");
      this.TemplateS = new FileManager("TemplateS.bin");
      this.TemplateL = new FileManager("TemplateL.bin");
      this.ScheduleM = new FileManager("ScheduleM.bin");
    }
    
    public void createWorker(Worker worker)  {
       try {
        workerList.addWorker(worker);
        Workers.writeToBin("Workers.bin", workerList);
       }
       catch (IOException e) { 
      
       }
    }

    public void createAnalysis(Analysis analysis) {
        analysisList.addAnalysis(analysis);
    }

    public ArrayList<Worker> getAllWorkers() {
        return workerList.getAll();
    }

    public void setWorkerList(WorkerList workerList){
        this.workerList = workerList;
    }

    public void setAnalysisList(AnalysisList analysisList){
        this.analysisList = analysisList;
    }

    public ArrayList<Analysis> getAllAnalysis() {
        return analysisList.getAll();
    }
    
    public void setWList() throws ClassNotFoundException
    {
       this.workerList = new WorkerList();
       try {
           for(int i = 0;i< ((WorkerList) Workers.loadFromBin()).getSize();i++)
           {
           workerList.addWorker(((WorkerList) Workers.loadFromBin()).getWorker(i));
           }      
        }
        catch (IOException e) {
           
        }
    }
    
 
}
