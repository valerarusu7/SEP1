package controller;

import model.Analysis;
import model.Model;
import model.Worker;
import view.viewInterface;

public class Controller {
    private Model model;
    private viewInterface view;


    public Controller(Model model, viewInterface view) {
        this.model = model;
        this.view = view;
    }

    public Model getModel() {
        return model;
    }

    public viewInterface getView() {
        return view;
    }

    public void createWorker() {
        String fullName = view.getAddWorkerViewController().getFullName();
        String id = view.getAddWorkerViewController().getIdWorker();

        Worker worker = new Worker(fullName, id);

        model.createWorker(worker);
    }
    
    public void createAnalysis() {
        String analysisName = view.getAddAnalysisViewController().getAnalysisName();

        Analysis analysis = new Analysis(analysisName);

        model.createAnalysis(analysis);
    }

    }

