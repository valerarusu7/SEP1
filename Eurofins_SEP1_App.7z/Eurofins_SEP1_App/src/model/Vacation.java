package model;

public class Vacation
{

}
