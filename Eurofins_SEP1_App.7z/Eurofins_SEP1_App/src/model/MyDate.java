package model;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class MyDate
{
   private int day, month, year;

   public MyDate(int day, int month, int year)
   {
      this.day = day;
      this.month = month;
      this.year = year;
   }
   
   public MyDate()
   {
      Calendar now = GregorianCalendar.getInstance();        
      this.day = now.get(Calendar.DAY_OF_MONTH);
      this.month = now.get(Calendar.MONTH) + 1;
      this.year = now.get(Calendar.YEAR);     
   }

   public void set(int day, int month, int year)
   {
      this.day = day;
      this.month = month;
      this.year = year;
      if (this.year < 0)
      {
         this.year = -this.year;
      }
      if (this.month < 1)
      {
         this.month = 1;
      }
      if (this.month > 12)
      {
         this.month = 12;
      }
      if (this.day < 1)
      {
         this.day = 1;
      }
      else if (this.day > numberOfDaysInMonth())
      {
         this.day = numberOfDaysInMonth();
      }
   }

   public String getMonthName()
   {
      switch (month)
      {
         case 1:
            return "January";
         case 2:
            return "February";
         case 3:
            return "March";
         case 4:
            return "April";
         case 5:
            return "May";
         case 6:
            return "June";
         case 7:
            return "July";
         case 8:
            return "August";
         case 9:
            return "September";
         case 10:
            return "October";
         case 11:
            return "November";
         default:
            return "December";
      }
   }

   public void stepForwardOneDay()
   {
      day++;
      if (day > numberOfDaysInMonth())
      {
         day = 1;
         month++;
         if (month > 13)
         {
            month = 1;
            year++;
         }
      }
   }

   public boolean isBefore(MyDate other)
   {
      if (this.year < other.year)
      {
         return true;
      }
      if (this.year > other.year)
      {
         return false;
      }
      if (this.month < other.year)
      {
         return true;
      }
      if (this.month > other.month)
      {
         return true;
      }
      if (this.day < other.day)
      {
         return true;
      }
      if (this.day > other.day)
      {
         return false;
      }
      return false;
   }

   public int getDay()
   {
      return day;
   }

   public int getMonth()
   {
      return month;
   }

   public int getYear()
   {
      return year;
   }

   public boolean isLeapYear()
   {
      return ((year % 4 == 0) && (year % 100 != 0) || (year % 400 == 0));
   }

   public int numberOfDaysInMonth()
   {
      switch (month)
      {
         case 2:
            if (isLeapYear())
            {
               return 29;
            }
            else
            {
               return 28;
            }
         case 4:
            return 30;
         case 6:
            return 30;
         case 9:
            return 30;
         case 11:
            return 30;
         default:
            return 31;
      }
   }

   public int yearsBetween(MyDate other)
   {
      int years = Math.abs(this.year - other.year);
      if (isBefore(other))
      {
      if (this.month < other.month)
      {
         return years;
      }
      if (this.month > other.month)
      {
         return years-1;
      }
      if (this.day < other.day)
      {
         return years;
      }
      else
      {
         return years-1;
      }
      }
      else 
      {
         if (other.month < this.month)
         {
            return years;
         }
         if (other.month > this.month)
         {
            return years-1;
         }
         if (other.day < this.day)
         {
            return years;
         }
         else
         {
            return years-1;
         }
      }
      
   }
   
   public String getAstroSign()
   {
      if ((month ==  3 && day >= 21 && day <= 31) || (month ==  4 && day >= 1 && day <= 19))    
      {
         return "Aries";
      }
      if ((month ==  4 && day >= 20 && day <= 31) || (month ==  5 && day >= 1 && day <= 20))    
      {
         return "Taurus";
      }
      if ((month ==  5 && day >= 21 && day <= 31) || (month ==  6 && day >= 1 && day <= 20))    
      {
         return "Gemini";
      }
      if ((month ==  6 && day >= 21 && day <= 31) || (month ==  7 && day >= 1 && day <= 22))    
      {
         return "Cancer";
      }
      if ((month ==  7 && day >= 23 && day <= 31) || (month ==  8 && day >= 1 && day <= 22))    
      {
         return "Leo";
      }
      if ((month ==  8 && day >= 23 && day <= 31) || (month ==  9 && day >= 1 && day <= 22))    
      {
         return "Virgo";
      }
      if ((month ==  9 && day >= 23 && day <= 31) || (month ==  10 && day >= 1 && day <= 22))    
      {
         return "Libra";
      }
      if ((month ==  10 && day >= 23 && day <= 31) || (month ==  11 && day >= 1 && day <= 21))    
      {
         return "Scorpio";
      }
      if ((month ==  11 && day >= 23 && day <= 31) || (month ==  12 && day >= 1 && day <= 21))    
      {
         return "Sagittarius";
      }
      if ((month ==  12 && day >= 22 && day <= 31) || (month ==  1 && day >= 1 && day <= 19))    
      {
         return "Capricorn";
      }
      if ((month ==  1 && day >= 20 && day <= 31) || (month ==  2 && day >= 1 && day <= 18))    
      {
         return "Aquaries";
      }
      if ((month ==  2 && day >= 19 && day <= 31) || (month ==  3 && day >= 1 && day <= 20))    
      {
         return "Capricorn";
      }
      return "You are not a human";
   }
   
   public String getAstroElement()
   {
      if ((this.getAstroSign().equals("Aries"))||(this.getAstroSign().equals("Leo"))||(this.getAstroSign().equals("Sagittarius")))
      {
       return "Fire";  
      }
      if ((this.getAstroSign().equals("Taurus"))||(this.getAstroSign().equals("Virgo"))||(this.getAstroSign().equals("Capricorn")))
      {
       return "Earth";  
      }
      if ((this.getAstroSign().equals("Cancer"))||(this.getAstroSign().equals("Scorpio"))||(this.getAstroSign().equals("Pisces")))
      {
       return "water";  
      }
      if ((this.getAstroSign().equals("Gemini"))||(this.getAstroSign().equals("Libra"))||(this.getAstroSign().equals("Aquaries")))
      {
       return "Air";  
      }
      return "what?";
   }
   
   public void stepForward(int day)
   {
      int x=0;
      while (x!=day) 
      {
         stepForwardOneDay();
         x++;
      }
   }
   
   static int convertToMonthNumber(String monthName)
   { switch(monthName)
      {
   case "January": return 1;
   case "February": return 2;
   case "March": return 3;
   case "April": return 4;
   case "May": return 5;
   case "June": return 6;
   case "July": return 7;
   case "August": return 8;
   case "September": return 9;
   case "October": return 10;
   case "November": return 11;
   case "December": return 12;
   default : return 1;
      }
      
   }
   
   public MyDate(int day, String monthName, int year)
   { 
      this(day, convertToMonthNumber(monthName), year );
   }


   public String toString()
   {
      return day + "/" + month + "/" + year;
   }
   
  public boolean equals(Object obj)
  {
     if (!(obj instanceof MyDate)) return false;
     
     MyDate other = (MyDate) obj;
     return this.day==other.day&&this.month==other.month&&this.year==other.year;
  }
}
