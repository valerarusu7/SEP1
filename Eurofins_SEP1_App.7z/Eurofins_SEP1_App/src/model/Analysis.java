package model;

public class Analysis
{
   private String name;
   private boolean isTraining;
   private String trainer;
   

   public Analysis(String name, boolean isTraining, String trainer)
   {
      this.name = name;
      this.isTraining = false;
      this.trainer = trainer;
   }
   
   public String getTrainer()
   {
      return trainer;
   }
   
   public void setTrainer(String trainer)
   {
      this.trainer = trainer;
   }
   
   public String getName()
   {
      return name;
   }

   public boolean isTraining()
   {
      return isTraining;
   }
   
   public boolean equals(Object obj)
   {
         if (!(obj instanceof Analysis))
         {
         return false;
         }
         Analysis other = (Analysis)obj;
         if(this.name != other.name)
         {
            return false;
         }
return true;
   }
   
   public boolean isLegal(String inputString)
   {
      String specialCharacters = " !#$%&'()*+,-./:;<=>?@[]^_`{|}~0123456789";
      String[] strlCharactersArray = new String[inputString.length()];
      for (int i = 0; i < inputString.length(); i++) {
           strlCharactersArray[i] = Character.toString(inputString.charAt(i));
      }
      int count = 0;
      for (int i = 0; i <  strlCharactersArray.length; i++) {
          if (specialCharacters.contains( strlCharactersArray[i])) {
              count++;
          }
      }
      if (inputString != null && count == 0) {
          return true;
      } else {
          return false;
      }
 }
   }

