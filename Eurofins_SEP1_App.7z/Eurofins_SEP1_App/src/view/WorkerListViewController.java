package view;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Worker;
import model.WorkerList;

public class WorkerListViewController {
    private AddWorkerViewController view;

    @FXML
    private ResourceBundle resources;

    @FXML private TableView<Worker> tableView;
    @FXML private TableColumn<Worker, String> idColumn;
    @FXML private TableColumn<Worker, String> nameColumn;
    private WorkerList list;

    @FXML
    private URL location;

    public WorkerListViewController(){
        list = new WorkerList();
        list = view.getWorkerList();
    }

    /*@FXML private void initialize() {
        tableView.setRowFactory(tableView -> {
            TableRow<Worker> newRow = new TableRow<>();
            return newRow;
        });

        nameColumn.setCellValueFactory(new PropertyValueFactory<Worker, String>("fullName"));
        idColumn.setCellValueFactory(new PropertyValueFactory<Worker, String>("iDnr"));

        for (int i = 0; i < list.getSize(); i++){
            tableView.getItems().add(list.getWorker(i));
        }
    }*/
}
