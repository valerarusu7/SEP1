package view;

public interface viewInterface {


}
