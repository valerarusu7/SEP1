package view;

import controller.Controller;
import javafx.stage.Stage;
import model.WorkerList;


public class GUI {
    private AddAnalysisViewController addAnalysisViewController;
    private AddWorkerViewController addWorkerViewController;
    private AnalysisListViewController analysisViewController;
    private MainScheduleAdminViewController mainScheduleAdminViewController;
    private MainScheduleWorkerViewController mainScheduleWorkerViewController;
    private ManageAnalysisViewController manageAnalysisViewController;
    private ManageWorkersViewController manageWorkersViewController;
    private RemoveAnalysisViewController removeAnalysisViewController;
    private RemoveWorkerViewController removeWorkerViewController;
    private SearchViewController searchViewController;
    private WindowLoginViewController windowLoginViewController;
    private WorkerListViewController workerListViewController;
    private Controller controller;
    private public static GUI me;
    private Stage primaryStage;

    public void displayAddAnalysisViewController() {
        primaryStage.getScene(addAnalysisViewController.getScene());
    }

    public void displayAddWorkerViewController(){
        primaryStage.setScene(addWorkerViewController.getScene());
    }

    public void displayAnalysisListViewController(){
        primaryStage.setScene(analysisViewController.getScene());
    }

    public void displayMainScheduleAdminViewController() {
        primaryStage.setScene(MainScheduleAdminViewController.getScene());
    }

    public void displayMainScheduleWorkerViewController(){
        primaryStage.setScene(MainScheduleWorkerViewController.getScene());
    }

    public void displayManageAnalysisViewController() {
        primaryStage.setScene(ManageAnalysisViewController.getScene());
    }

    public void displayManageWorkersViewController() {
        primaryStage.setScene(ManageWorkersViewController.getScene());
    }

    public void displayRemoveAnalysisViewController() {
        primaryStage.setScene(RemoveAnalysisViewController.getScene());
    }

    public void displayRemoveWorkerViewController() {
        primaryStage.setScene(RemoveWorkerViewController.getScene());
    }

    public void displaySearchViewController() {
        primaryStage.setScene(SearchViewController.getScene());
    }

    public void displayWindowLoginViewController(){
        primaryStage.setScene(WindowLoginViewController.getScene());
    }

    public void displayWorkerListViewController(){
        primaryStage.setScene(WorkerListViewController.getScene());
    }

    }





