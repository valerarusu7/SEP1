package view;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        AnchorPane mainPane;
        mainPane = FXMLLoader.load(Main.class.getResource("MainScheduleWorker.fxml"));
        primaryStage.setScene(new Scene(mainPane));
        Image icon = new Image("img/eurofins_logo.png");
        primaryStage.getIcons().add(icon);
        primaryStage.setTitle("Eurofins Work Schedule");
        primaryStage.show();
    }



    public static void main(String[] args) {
        launch(args);
    }
}
