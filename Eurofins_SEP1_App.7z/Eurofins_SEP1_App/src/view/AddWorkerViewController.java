package view;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import model.Worker;
import model.WorkerList;

public class AddWorkerViewController
{
   @FXML private TextField fullName;
   @FXML private TextField idWorker;
   @FXML private ResourceBundle resources;
   @FXML private URL location;
   private WorkerList list;
   private Scene scene;

   public AddWorkerViewController(){
      this.list = new WorkerList();
   }

   public void initialize() {

   }
   public void ReturnbuttonPressed(ActionEvent event) throws IOException {
      ((Node)event.getSource()).getScene().getWindow().hide();
      Stage primaryStage = new Stage();
      Pane returnB = (Pane) FXMLLoader.load(Main.class.getResource("Manage-Workers.fxml"));
      primaryStage.setScene(new Scene(returnB)); 
      Image icon = new Image("img/eurofins_logo.png");
      primaryStage.getIcons().add(icon);
      primaryStage.show();
   }

   @FXML private void addWorkerToTheList(){
      String name = fullName.getText();
      String id = idWorker.getText();

      Worker worker = new Worker(name, id);
      list.add(worker);
   }

   public WorkerList getWorkerList(){
      return list;
   }

   public Scene getScene(){
      return scene;
   }


}
