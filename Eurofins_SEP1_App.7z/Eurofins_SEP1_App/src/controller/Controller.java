package controller;

import model.Model;
import view.viewInterface;

public class Controller {
private Model model;
private viewInterface view;


}

