package controller;

import java.io.IOException;

import model.Analysis;
import model.AnalysisList;
import model.Model;
import model.Worker;
import model.WorkerList;
import view.ViewInterface;

public class Controller
{
   private Model model;
   private ViewInterface view;

   public Controller(Model model, ViewInterface view)
   {
      this.model = model;
      this.view = view;
   }

   public Model getModel()
   {
      return model;
   }

   public ViewInterface getView()
   {
      return view;
   }

   public void createWorker()
   {
      String fullName = view.getAddWorkerViewController().getFullName();
      String id = view.getAddWorkerViewController().getIdWorker();
      AnalysisList training = new AnalysisList();

      Worker worker = new Worker(fullName, id, null, training);
      WorkerList workerList = model.getTheListOfWorkers();

      boolean ok = true;
      for (int i = 0; i < workerList.getSize(); i++)
      {
         if (worker.getIDnr().equals(workerList.getWorker(i).getIDnr()))
         {
            ok = false;
         }
      }

      if (ok == true && (!(worker.getFullName().equals("")))
            && (!(worker.getIDnr().equals(""))))
      {
         model.createWorker(worker);
         view.displayWorkerListViewController();
      }
      else
      {
         view.showError("addWorker");
      }

   }

   public void createAnalysis()
   {
      String analysisName = view.getAddAnalysisViewController()
            .getAnalysisName();

      Analysis analysis = new Analysis(analysisName);

      AnalysisList analysisList = model.getTheListOfAnalysis();

      boolean ok = true;
      for (int i = 0; i < analysisList.getSize(); i++)
      {
         if (analysis.equals(analysisList.getAnalysis(i)))
         {
            ok = false;
         }
      }

      if (ok == true && (!(analysis.getName().equals(""))))
      {
         model.createAnalysis(analysis);
         view.displayAnalysisListViewController();

      }
      else
      {
         view.showError("addAnalysis");
      }
   }

   public void createTraining() throws IOException /////////////////////////////////////
   {
      Analysis training = view.getAddWorkerViewController().getComboValue();

      AnalysisList existingTraining = view.getAddWorkerViewController()
            .getTrainingFromTableView();

      boolean ok = true;
      for (int i = 0; i < existingTraining.getSize(); i++)
      {
         if (training.equals(existingTraining.getAnalysis(i)))
         {
            ok = false;
         }
      }

      if (ok == true)
      {
         model.createTraining(training);
      }
   }

   public void removeWorker()
   {
      String fullName = view.getAddWorkerViewController().getFullName();
      String id = view.getAddWorkerViewController().getIdWorker();

      Worker worker = new Worker(fullName, id);

      model.removeWorker(worker);

   }

   public void removeAnalysis()
   {
      String analysisName = view.getAddAnalysisViewController()
            .getAnalysisName();

      Analysis analysis = new Analysis(analysisName);

      model.removeAnalysis(analysis);
   }
}
