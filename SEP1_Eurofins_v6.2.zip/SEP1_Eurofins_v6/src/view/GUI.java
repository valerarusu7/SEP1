package view;

import controller.Controller;
import javafx.application.Application;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.IOException;

public class GUI extends Application implements ViewInterface
{
   private Controller controller;
   private static GUI me;
   private Stage primaryStage;
   private AddAnalysisViewController addAnalysisViewController;
   private AddWorkerViewController addWorkerViewController;
   private AnalysisListViewController analysisListViewController;
   private MainScheduleAdminViewController mainScheduleAdminViewController;
   private MainScheduleWorkerViewController mainScheduleWorkerViewController;
   private ManageAnalysisViewController manageAnalysisViewController;
   private ManageWorkersViewController manageWorkersViewController;
   private RemoveAnalysisViewController removeAnalysisViewController;
   private RemoveWorkerViewController removeWorkerViewController;
   private SearchViewController searchViewController;
   private WindowLoginViewController windowLoginViewController;
   private WorkerListViewController workerListViewController;
   private WorkerProfileViewController workerProfileViewController;
   private VacationViewController vacationViewController;
   private AssignTaskViewController assignTaskViewController;
   private SearchWorkerViewController searchWorkerViewController;

   public GUI()
   {
      if (me == null)
      {
         me = this;
      }
   }

   public void start(Controller controller)
   {
      this.controller = controller;
      new Thread(new Runnable()
      {
         public void run()
         {
            Application.launch(GUI.class);
         }
      }).start();

   }

   @Override // Application
   public void start(Stage primaryStage)
   {
      if (me != this)
      {
         me.start(primaryStage);
         return;
      }
      this.primaryStage = primaryStage;

      try
      {
         addAnalysisViewController = new AddAnalysisViewController(this);
         addWorkerViewController = new AddWorkerViewController(this);
         analysisListViewController = new AnalysisListViewController(this);
         mainScheduleAdminViewController = new MainScheduleAdminViewController(
               this);
         mainScheduleWorkerViewController = new MainScheduleWorkerViewController(
               this);
         manageAnalysisViewController = new ManageAnalysisViewController(this);
         manageWorkersViewController = new ManageWorkersViewController(this);
         removeAnalysisViewController = new RemoveAnalysisViewController(this);
         removeWorkerViewController = new RemoveWorkerViewController(this);
         searchViewController = new SearchViewController(this);
         windowLoginViewController = new WindowLoginViewController(this);
         workerListViewController = new WorkerListViewController(this);
         workerProfileViewController = new WorkerProfileViewController(this);
         vacationViewController = new VacationViewController(this);
         assignTaskViewController = new AssignTaskViewController(this);
         searchWorkerViewController = new SearchWorkerViewController(this);

      }
      catch (IOException e)
      {
         e.printStackTrace();
      }
      displayWindowLoginViewController();

      primaryStage.show();
   }

   public Controller getController()
   {
      return controller;
   }

   public AddAnalysisViewController getAddAnalysisViewController()
   {
      return addAnalysisViewController;
   }

   public VacationViewController getVacationViewController()
   {
      return vacationViewController;
   }

   public AddWorkerViewController getAddWorkerViewController()
   {
      return addWorkerViewController;
   }

   public AnalysisListViewController getAnalysisListViewController()
   {
      return analysisListViewController;
   }

   public MainScheduleAdminViewController getMainScheduleAdminViewController()
   {
      return mainScheduleAdminViewController;
   }

   public MainScheduleWorkerViewController getMainScheduleWorkerViewController()
   {
      return mainScheduleWorkerViewController;
   }

   public ManageAnalysisViewController getManageAnalysisViewController()
   {
      return manageAnalysisViewController;
   }

   public ManageWorkersViewController getManageWorkersViewController()
   {
      return manageWorkersViewController;
   }

   public RemoveAnalysisViewController getRemoveAnalysisViewController()
   {
      return removeAnalysisViewController;
   }

   public RemoveWorkerViewController getRemoveWorkerViewController()
   {
      return removeWorkerViewController;
   }

   public SearchViewController getSearchViewController()
   {
      return searchViewController;
   }

   public WindowLoginViewController getWindowLoginViewController()
   {
      return windowLoginViewController;
   }

   public WorkerListViewController getWorkerListViewController()
   {
      return workerListViewController;
   }

   public WorkerProfileViewController getWorkerProfileViewController()
   {
      return workerProfileViewController;
   }

   public AssignTaskViewController getAssignTaskViewController()
   {
      return assignTaskViewController;
   }

   public SearchWorkerViewController getSearchWorkerViewController()
   {
      return searchWorkerViewController;
   }

   public void displaySearchWorkerViewController()
   {
      primaryStage.setScene(searchWorkerViewController.getScene());
      primaryStage.centerOnScreen();
      primaryStage.setTitle("Search");
      Image icon = new Image("img/eurofins_logo.png");
      primaryStage.getIcons().add(icon);
   }

   public void displayAssignTaskViewController()
   {
      primaryStage.setScene(assignTaskViewController.getScene());
      primaryStage.centerOnScreen();
      primaryStage.setTitle("Assign Task");
      Image icon = new Image("img/eurofins_logo.png");
      primaryStage.getIcons().add(icon);
   }

   public void displayWorkerProfileViewController()
   {
      primaryStage.setScene(workerProfileViewController.getScene());
      primaryStage.centerOnScreen();
      primaryStage.setTitle("Worker Profile");
      Image icon = new Image("img/eurofins_logo.png");
      primaryStage.getIcons().add(icon);
   }

   public void displayVacationViewController()
   {
      primaryStage.setScene(vacationViewController.getScene());
      primaryStage.centerOnScreen();
      primaryStage.setTitle("Vacation");
      Image icon = new Image("img/eurofins_logo.png");
      primaryStage.getIcons().add(icon);
   }

   public void displayAddAnalysisViewController()
   {
      primaryStage.setScene(addAnalysisViewController.getScene());
      primaryStage.centerOnScreen();
      primaryStage.setTitle("Add Analysis");
      Image icon = new Image("img/eurofins_logo.png");
      primaryStage.getIcons().add(icon);
   }

   public void displayAddWorkerViewController()
   {
      primaryStage.setScene(addWorkerViewController.getScene());
      primaryStage.centerOnScreen();
      primaryStage.setTitle("Add Worker");
      Image icon = new Image("img/eurofins_logo.png");
      primaryStage.getIcons().add(icon);
   }

   public void displayAnalysisListViewController()
   {
      primaryStage.setScene(analysisListViewController.getScene());
      primaryStage.centerOnScreen();
      primaryStage.setTitle("Analysis List");
      Image icon = new Image("img/eurofins_logo.png");
      primaryStage.getIcons().add(icon);
   }

   public void displayMainScheduleAdminViewController()
   {
      primaryStage.setScene(mainScheduleAdminViewController.getScene());
      primaryStage.centerOnScreen();
      primaryStage.setTitle("Work Schedule");
      Image icon = new Image("img/eurofins_logo.png");
      primaryStage.getIcons().add(icon);
   }

   public void displayMainScheduleWorkerViewController()
   {
      primaryStage.setScene(mainScheduleWorkerViewController.getScene());
      primaryStage.centerOnScreen();
      primaryStage.setTitle("Work Schedule");
      Image icon = new Image("img/eurofins_logo.png");
      primaryStage.getIcons().add(icon);
   }

   public void displayManageAnalysisViewController()
   {
      primaryStage.setScene(manageAnalysisViewController.getScene());
      primaryStage.centerOnScreen();
      primaryStage.setTitle("Manage Analysis");
      Image icon = new Image("img/eurofins_logo.png");
      primaryStage.getIcons().add(icon);
   }

   public void displayManageWorkersViewController()
   {
      primaryStage.setScene(manageWorkersViewController.getScene());
      primaryStage.centerOnScreen();
      primaryStage.setTitle("Manage Workers");
      Image icon = new Image("img/eurofins_logo.png");
      primaryStage.getIcons().add(icon);
   }

   public void displayRemoveAnalysisViewController()
   {
      primaryStage.setScene(removeAnalysisViewController.getScene());
      primaryStage.centerOnScreen();
      primaryStage.setTitle("Remove Analysis");
      Image icon = new Image("img/eurofins_logo.png");
      primaryStage.getIcons().add(icon);
   }

   public void displayRemoveWorkerViewController()
   {
      primaryStage.setScene(removeWorkerViewController.getScene());
      primaryStage.centerOnScreen();
      primaryStage.setTitle("Remove Worker");
      Image icon = new Image("img/eurofins_logo.png");
      primaryStage.getIcons().add(icon);
   }

   public void displaySearchViewController()
   {
      primaryStage.setScene(searchViewController.getScene());
      primaryStage.centerOnScreen();
      primaryStage.setTitle("Search");
      Image icon = new Image("img/eurofins_logo.png");
      primaryStage.getIcons().add(icon);
   }

   public void displayWindowLoginViewController()
   {
      primaryStage.setScene(windowLoginViewController.getScene());
      primaryStage.centerOnScreen();
      primaryStage.setTitle("Login");
      Image icon = new Image("img/eurofins_logo.png");
      primaryStage.getIcons().add(icon);
   }

   public void displayWorkerListViewController()
   {
      primaryStage.setScene(workerListViewController.getScene());
      primaryStage.centerOnScreen();
      primaryStage.setTitle("Worker List");
      Image icon = new Image("img/eurofins_logo.png");
      primaryStage.getIcons().add(icon);
   }

   public void showError(String type)
   {
      switch (type)
      {
         case "addAnalysis":
            addAnalysisViewController.showError();
         case "addWorker":
            addWorkerViewController.showError();
      }

   }

}
