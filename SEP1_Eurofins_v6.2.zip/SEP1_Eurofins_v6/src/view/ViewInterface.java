package view;

import controller.Controller;
import javafx.stage.Stage;

public interface ViewInterface
{

   public void start(Stage primaryStage);

   public Controller getController();

   public AddAnalysisViewController getAddAnalysisViewController();

   public AddWorkerViewController getAddWorkerViewController();

   public AnalysisListViewController getAnalysisListViewController();

   public MainScheduleAdminViewController getMainScheduleAdminViewController();

   public MainScheduleWorkerViewController getMainScheduleWorkerViewController();

   public ManageAnalysisViewController getManageAnalysisViewController();

   public ManageWorkersViewController getManageWorkersViewController();

   public RemoveAnalysisViewController getRemoveAnalysisViewController();

   public RemoveWorkerViewController getRemoveWorkerViewController();

   public SearchViewController getSearchViewController();

   public SearchWorkerViewController getSearchWorkerViewController();

   public WindowLoginViewController getWindowLoginViewController();

   public WorkerListViewController getWorkerListViewController();

   public AssignTaskViewController getAssignTaskViewController();

   public void displayAddAnalysisViewController();

   public void displayAddWorkerViewController();

   public void displayAnalysisListViewController();

   public void displaySearchWorkerViewController();

   public void displayMainScheduleAdminViewController();

   public void displayMainScheduleWorkerViewController();

   public void displayManageAnalysisViewController();

   public void displayManageWorkersViewController();

   public void displayRemoveAnalysisViewController();

   public void displayRemoveWorkerViewController();

   public void displaySearchViewController();

   public void displayWindowLoginViewController();

   public void displayWorkerListViewController();

   public void displayAssignTaskViewController();

   public void showError(String type);

}
