package model;

import java.io.IOException;
import java.util.ArrayList;

public interface Model
{

   public void createWorker(Worker worker);

   public void createAnalysis(Analysis analysis);

   public void createTraining(Analysis analysis);

   public ArrayList<Worker> getAllWorkers();

   public ArrayList<Analysis> getAllAnalysis();

   public ArrayList<Analysis> getAllTrainings();

   public void setWList() throws ClassNotFoundException;

   public void setAList() throws ClassNotFoundException;

   public void removeWorker(Worker worker);

   public void removeAnalysis(Analysis analysis);

   public Analysis getAnalysis(String name) throws IOException;

   public AnalysisList getTheListOfAnalysis();

   public WorkerList getTheListOfWorkers();

}
