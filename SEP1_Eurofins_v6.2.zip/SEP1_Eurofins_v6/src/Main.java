import controller.Controller;
import model.Model;
import model.ModelManager;
import view.GUI;

public class Main
{
   public static void main(String[] args) throws ClassNotFoundException
   {
      Model model = new ModelManager();
      GUI view = new GUI();
      Controller controller = new Controller(model, view);
      view.start(controller);
   }
}
