package model;

import java.io.IOException;
import java.util.ArrayList;

public class ModelManager implements Model
{
   private WorkerList workerList;
   private Worker jobs;
   private AnalysisList analysisList;
   private AnalysisList training;
   private FileManager Workers;
   private FileManager Analysis;
   private FileManager TemplateS;
   private FileManager TemplateL;
   private FileManager ScheduleM;

   public ModelManager() throws ClassNotFoundException
   {
      this.Workers = new FileManager("Workers.bin");
      this.Analysis = new FileManager("Analysis.bin");
      this.TemplateS = new FileManager("TemplateS.bin");
      this.TemplateL = new FileManager("TemplateL.bin");
      this.ScheduleM = new FileManager("ScheduleM.bin");
      this.training = new AnalysisList();
      this.setWList();
      this.setAList();
   }

   public void createWorker(Worker worker)
   {
      try
      {
         workerList.addWorker(worker);
         Workers.writeToBin("Workers.bin", workerList);
      }
      catch (IOException e)
      {

      }
   }

   public void createAnalysis(Analysis analysis)
   {
      try
      {
         analysisList.addAnalysis(analysis);
         Analysis.writeToBin("Analysis.bin", analysisList);
      }
      catch (IOException e)
      {

      }
   }
   
   public void createTraining(Analysis analysis)
   {
      training.addAnalysis(analysis);
   }

   public ArrayList<Worker> getAllWorkers()
   {
      return workerList.getAll();
   }

   public void setWorkerList(WorkerList workerList)
   {
      this.workerList = workerList;
   }

   public void setAnalysisList(AnalysisList analysisList)
   {
      this.analysisList = analysisList;
   }

   public ArrayList<Analysis> getAllAnalysis()
   {
      return analysisList.getAll();
   }
   
   public ArrayList<Analysis> getAllTrainings()
   {
      return training.getJobList();
   }


   public void setWList() throws ClassNotFoundException
   {
      this.workerList = new WorkerList();
      try
      {
         for (int i = 0; i < ((WorkerList) Workers.loadFromBin())
               .getSize(); i++)
         {
            workerList
                  .addWorker(((WorkerList) Workers.loadFromBin()).getWorker(i));
         }
      }
      catch (IOException e)
      {

      }
   }

   public void setAList() throws ClassNotFoundException
   {
      this.analysisList = new AnalysisList();
      try
      {
         for (int i = 0; i < ((AnalysisList) Analysis.loadFromBin())
               .getSize(); i++)
         {
            analysisList.addAnalysis(
                  ((AnalysisList) Analysis.loadFromBin()).getAnalysis(i));
         }
      }
      catch (IOException e)
      {

      }
   }

   public void removeWorker(Worker worker)
   {
      try
      {
         workerList.removeWorker(worker);
         Workers.writeToBin("Workers.bin", workerList);
      }
      catch (IOException e)
      {

      }
   }

   public void removeAnalysis(Analysis analysis)
   {
      try
      {
         analysisList.removeAnalysis(analysis);
         Analysis.writeToBin("Analysis.bin", analysisList);
      }
      catch (IOException e)
      {

      }
   }
   
   public Analysis getAnalysis(String name) throws IOException
   {
      return analysisList.getAnalysis(name);
   }

}
