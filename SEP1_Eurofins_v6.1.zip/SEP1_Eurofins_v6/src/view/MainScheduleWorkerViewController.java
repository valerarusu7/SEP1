package view;

import java.io.IOException;
import java.time.LocalDate;
import java.time.temporal.TemporalField;
import java.time.temporal.WeekFields;
import java.util.Locale;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;

public class MainScheduleWorkerViewController
{

   private Scene scene;
   private GUI gui;
   private LocalDate localDate;
   @FXML
   private Label firstDay, secondDay, thirdDay, fourthDay, fifthDay, sixthDay,
         seventhDay;
   @FXML
   private Label Day, DayTwo, DayThree, DayFour, DayFive, DaySix, DaySeven;
   @FXML
   private Label MasterLabel;

   public MainScheduleWorkerViewController(GUI gui) throws IOException
   {
      this.gui = gui;
      FXMLLoader loader = new FXMLLoader();
      loader.setLocation(getClass().getResource("MainScheduleWorker.fxml"));
      loader.setController(this);
      Parent root = loader.load();
      this.scene = new Scene(root);
      this.localDate = LocalDate.now();
      this.setDates();
      this.setNameDates();
      this.setMonthAndWeek();

   }

   @FXML
   void initialize()
   {
   }

   public void setMonthAndWeek()
   {
      TemporalField woy = WeekFields.of(Locale.getDefault())
            .weekOfWeekBasedYear();
      int weekNumber = localDate.get(woy);
      this.MasterLabel.setText(
            this.localDate.getMonth().name() + " Week Number: " + weekNumber);
   }

   @FXML
   void goForwardInWeekPressed()
   {
      this.localDate = this.localDate.plusDays(7);
      this.setDates();
      this.setNameDates();
      this.setMonthAndWeek();
   }

   @FXML
   void goBackwardInWeekPressed()
   {
      this.localDate = this.localDate.minusDays(7);
      this.setDates();
      this.setNameDates();
      this.setMonthAndWeek();
   }

   public void setDates()
   {

      firstDay.setText(this.localDate.getDayOfMonth() + "/"
            + this.localDate.getMonth().getValue() + "/"
            + this.localDate.getYear());
      secondDay.setText(this.localDate.plusDays(1).getDayOfMonth() + "/"
            + this.localDate.plusDays(1).getMonth().getValue() + "/"
            + this.localDate.plusDays(1).getYear());
      thirdDay.setText(this.localDate.plusDays(2).getDayOfMonth() + "/"
            + this.localDate.plusDays(2).getMonth().getValue() + "/"
            + this.localDate.plusDays(2).getYear());
      fourthDay.setText(this.localDate.plusDays(3).getDayOfMonth() + "/"
            + this.localDate.plusDays(3).getMonth().getValue() + "/"
            + this.localDate.plusDays(3).getYear());
      fifthDay.setText(this.localDate.plusDays(4).getDayOfMonth() + "/"
            + this.localDate.plusDays(4).getMonth().getValue() + "/"
            + this.localDate.plusDays(4).getYear());
      sixthDay.setText(this.localDate.plusDays(5).getDayOfMonth() + "/"
            + this.localDate.plusDays(5).getMonth().getValue() + "/"
            + this.localDate.plusDays(5).getYear());
      seventhDay.setText(this.localDate.plusDays(6).getDayOfMonth() + "/"
            + this.localDate.plusDays(6).getMonth().getValue() + "/"
            + this.localDate.plusDays(6).getYear());
   }

   public void setNameDates()
   {
      Day.setText(localDate.getDayOfWeek().toString());
      DayTwo.setText(localDate.plusDays(1).getDayOfWeek().toString());
      DayThree.setText(localDate.plusDays(2).getDayOfWeek().toString());
      DayFour.setText(localDate.plusDays(3).getDayOfWeek().toString());
      DayFive.setText(localDate.plusDays(4).getDayOfWeek().toString());
      DaySix.setText(localDate.plusDays(5).getDayOfWeek().toString());
      DaySeven.setText(localDate.plusDays(6).getDayOfWeek().toString());
   }

   public void SearchbuttonPressed()
   {
      gui.displaySearchWorkerViewController();
   }

   public void LogOutButtonPressed()
   {
      gui.displayWindowLoginViewController();
   }

   public Scene getScene()
   {
      return scene;
   }
}