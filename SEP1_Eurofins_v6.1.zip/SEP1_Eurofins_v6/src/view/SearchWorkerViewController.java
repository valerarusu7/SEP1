package view;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

public class SearchWorkerViewController
{
   private GUI gui;
   private Scene scene;

   @FXML
   void initialize()
   {
   }

   public SearchWorkerViewController(GUI gui) throws IOException
   {
      this.gui = gui;
      FXMLLoader loader = new FXMLLoader();
      loader.setLocation(getClass().getResource("SearchWorker.fxml"));
      loader.setController(this);

      Parent root = loader.load();
      this.scene = new Scene(root);
   }

   public void ReturnbuttonPressed()
   {
      gui.displayMainScheduleWorkerViewController();
   }

   public Scene getScene()
   {
      return scene;
   }
}
