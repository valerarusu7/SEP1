package view;

import java.io.IOException;
import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Analysis;
import model.AnalysisList;
import model.Worker;
import model.WorkerList;

public class AddWorkerViewController
{

   private WorkerList list;
   private Scene scene;
   private GUI gui;
   private ArrayList<Analysis> analysisList;
   private ArrayList<Analysis> training;
   @FXML
   private TextField fullName;
   @FXML
   private TextField idWorker;
   @FXML
   private TableView tableView;
   @FXML
   private TableColumn nameColumn;
   @FXML
   private TableColumn selectColumn;
   @FXML
   private ComboBox<Analysis> comboAnalysis;
   @FXML
   private TableView tableViewAnalysisForWorker;
   @FXML
   private TableColumn nameAnalysisColumn;

   public AddWorkerViewController(GUI gui) throws IOException
   {
      this.gui = gui;
      FXMLLoader loader = new FXMLLoader();
      loader.setLocation(getClass().getResource("AddWorker.fxml"));
      loader.setController(this);
      Parent root = loader.load();
      this.scene = new Scene(root);
   }

   public void initialize() throws ClassNotFoundException
   {
      tableViewAnalysisForWorker.setRowFactory(tableView -> {
         TableRow<Analysis> newRow = new TableRow<>();
         return newRow;
      });

      nameAnalysisColumn.setCellValueFactory(
            new PropertyValueFactory<Analysis, String>("name"));

      fullName.setText("");
      idWorker.setText("");

      this.training = new ArrayList();
   }

   public String getFullName()
   {
      return fullName.getText();
   }

   public String getIdWorker()
   {
      return idWorker.getText();
   }

   public void ReturnbuttonPressed()
   {
      gui.displayManageWorkersViewController();
      fullName.setText("");
      idWorker.setText("");
   }

   public Scene getScene()
   {
      return scene;
   }

   @FXML
   private void addWorker()
   {
      gui.getController().createWorker();
      gui.getController().getView().displayWorkerListViewController();
      gui.getController().getView().getWorkerListViewController().updateItems();
      gui.getController().getView().getRemoveWorkerViewController()
            .updateItems();
      gui.getController().getView().getAssignTaskViewController().updateItems();
      fullName.setText("");
      idWorker.setText("");
   }

   public void UpdateList()
   {
      comboAnalysis.setItems(FXCollections.observableArrayList(
            gui.getController().getModel().getAllAnalysis()));
   }

   public Analysis getComboValue() throws IOException
   {
     // Analysis varName = comboAnalysis.getSelectionModel().getSelectedItem();
      String value = comboAnalysis.getSelectionModel().getSelectedItem()
            .toString(); 
    return  gui.getController().getModel().getAnalysis(value);

   }

   public void addAnalysis() throws IOException
   {
      gui.getController().createTraining();
      gui.getAddWorkerViewController().updateItems();
   }

   public void updateItems()
   {
      this.training = gui.getController().getModel().getAllTrainings();
      tableViewAnalysisForWorker
            .setItems(FXCollections.observableList(training));
      tableViewAnalysisForWorker.refresh();
   }

}
