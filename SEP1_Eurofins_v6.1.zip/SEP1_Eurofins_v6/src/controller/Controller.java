package controller;

import java.io.IOException;

import model.Analysis;
import model.AnalysisList;
import model.Model;
import model.Worker;
import view.ViewInterface;

public class Controller
{
   private Model model;
   private ViewInterface view;

   public Controller(Model model, ViewInterface view)
   {
      this.model = model;
      this.view = view;
   }

   public Model getModel()
   {
      return model;
   }

   public ViewInterface getView()
   {
      return view;
   }

   public void createWorker()
   {
      String fullName = view.getAddWorkerViewController().getFullName();
      String id = view.getAddWorkerViewController().getIdWorker();

      Worker worker = new Worker(fullName, id);
      model.createWorker(worker);
   }

   public void createAnalysis()
   {
      String analysisName = view.getAddAnalysisViewController()
            .getAnalysisName();

      Analysis analysis = new Analysis(analysisName);

      model.createAnalysis(analysis);
   }
   
   public void createTraining() throws IOException
   {
      model.createTraining(view.getAddWorkerViewController().getComboValue());
   }

   public void removeWorker()
   {
      String fullName = view.getAddWorkerViewController().getFullName();
      String id = view.getAddWorkerViewController().getIdWorker();

      Worker worker = new Worker(fullName, id);

      model.removeWorker(worker);

   }

   public void removeAnalysis()
   {
      String analysisName = view.getAddAnalysisViewController()
            .getAnalysisName();

      Analysis analysis = new Analysis(analysisName);

      model.removeAnalysis(analysis);
   }
}
