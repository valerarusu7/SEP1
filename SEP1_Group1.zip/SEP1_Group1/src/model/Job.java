package model;

/** Description of Job 
*
* @author Group 1
* @version 1.0 15th December 2018
*/
import java.io.IOException;
import java.io.Serializable;

/** Class which represents a job */
public class Job extends Task implements Serializable
{
   /** Boolean representing whether or not the given Job is training */
   private boolean isTraining;
   /** The worker who is training this worker */
   private Worker trainer;
   /** The analysis being done */
   private Analysis analysis;

   /**
    * Constructor that initialises the private variables with the given
    * parameters and sets the Job's worker if he has the given analysis in his
    * training private instance variable
    * 
    * @param who
    *           The worker/employee doing the task
    * @param start
    *           The date of the Job
    * @param analysis
    *           The analysis being done
    * @exception IOException
    *               This exception is thrown when the analysis being given is
    *               not in the worker's training
    */
   public Job(Worker who, MyDate start, Analysis analysis) throws IOException
   {
      super(who, start);
      this.isTraining = false;
      this.trainer = null;
      for (int i = 0; i < super.getWorker().getTraining().getJobList()
            .size(); i++)
      {
         if (super.getWorker().getTraining().getJobList().get(i)
               .equals(analysis))
         {
            this.analysis = analysis;
            break;
         }
      }
      if (this.analysis.equals(null))
         throw new IOException(
               "The analysis couldn't be found in the workers training and he is not capable of doing it");
   }

   /**
    * Constructor that initialises the private variables with the given
    * parameters and sets his training to false and his trainer to null
    * 
    * @param start
    *           The date of the Job
    * @param analysis
    *           The analysis being done
    */
   public Job(MyDate start, Analysis analysis)
   {
      super(start);
      this.isTraining = false;
      this.trainer = null;
      this.analysis = analysis;
   }

   /**
    * Constructor that initialises the private variables with the given
    * parameters and sets the training to true and assigns him a trainer
    * 
    * @param who
    *           The worker/employee doing the task
    * @param start
    *           The date of the Job
    * @param analysis
    *           The analysis being done
    * @param trainer
    *           The trainer assigned to help the worker with this job (he's also
    *           a of type Worker)
    * @exception IOException
    *               This exception is thrown when the worker hasn't been
    *               assigned and is supposed to be thrown when you check the
    *               present worker in a template
    */
   public Job(Worker who, MyDate start, Analysis analysis, Worker trainer)
         throws IOException
   {
      super(who, start);
      this.isTraining = true;
      this.trainer = trainer;
      this.analysis = analysis;
      super.getWorker().addToTraining(analysis);
   }

   /**
    * Constructor that initialises the private variables with the given
    * parameters and sets the training to true and assigns him a trainer
    * 
    * @param start
    *           The date of the Job
    * @param analysis
    *           The analysis being done
    * @param trainer
    *           The trainer assigned to help the worker with this job (he's also
    *           a of type Worker)
    * @exception IOException
    *               This exception is thrown when the worker hasn't been
    *               assigned and is supposed to be thrown when you check the
    *               present worker in a template
    */
   public Job(MyDate start, Analysis analysis, Worker trainer)
         throws IOException
   {
      super(start);
      this.isTraining = true;
      this.trainer = trainer;
      this.analysis = analysis;
      super.getWorker().addToTraining(analysis);
   }

   /**
    * Getter method for the private instance variable isTraining
    * 
    * @return The state of the boolean private instance variable
    */
   public boolean getIsTraining()
   {
      return this.isTraining;
   }

   /**
    * Getter method for the private instance variable trainer
    * 
    * @return The trainer
    * @exception IOException
    *               This exception is thrown when there is no assigned trainer
    *               to the job
    */
   public Worker getTrainer() throws IOException
   {
      if (this.trainer.equals(null))
         throw new IOException("This task has no trainer assigned to it");
      else
         return this.trainer;
   }

   /**
    * Getter method for the private instance variable analysis
    * 
    * @return The analysis
    * @exception IOException
    *               This exception is thrown when there is no analysis assigned
    *               to the job, atm impossible to get this
    */
   public Analysis getAnalysis() throws IOException
   {
      if (this.analysis.equals(null))
         throw new IOException(
               "This task has no analysis assigned to it, wait how did you get this exception ?!?");
      else
         return this.analysis;
   }

   /**
    * Compares 2 objects of type Job
    * 
    * @param obj
    *           The second object that's being compared
    * @return Whether the 2 objects are the same or not
    * @exception NullPointerException
    *               The method would throw this type of exception when one of
    *               the objects is null
    */
   public boolean equals(Object obj) throws NullPointerException
   {
      if (super.equals(obj))
      {
         Job other = (Job) obj;
         return this.isTraining == other.isTraining
               && this.analysis.equals(other.analysis)
               && this.trainer.equals(other.trainer);
      }
      else
         return false;
   }
}