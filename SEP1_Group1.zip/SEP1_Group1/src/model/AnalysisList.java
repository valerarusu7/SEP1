package model;

/** Description of AnalysisList 
*
* @author Group 1
* @version 1.0 15th December 2018
*/
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

/** Class which represents multiple analysis */
public class AnalysisList implements Serializable
{
   /** The collection of every Analysis that has been added */
   private ArrayList<Analysis> jobs;

   /**
    * Constructor that initialises the ArrayList
    */
   public AnalysisList()
   {
      this.jobs = new ArrayList<>();
   }

   /**
    * Mutator that that sets the list
    * 
    * @param jobs
    *           The variable used to set the private list
    */
   public void setJobs(ArrayList<Analysis> jobs)
   {
      this.jobs = jobs;
   }

   /**
    * Mutator that deletes a certain analysis from the list
    * 
    * @param analysis
    *           The variable being removed
    */
   public void removeAnalysis(Analysis analysis)
   {
      jobs.remove(analysis);
   }

   /**
    * Getter method for the list
    * 
    * @return The private list
    */
   public ArrayList<Analysis> getAll()
   {
      return jobs;
   }

   /**
    * Method that adds an analysis to the ArrayList
    * 
    * @param analysis
    *           The analysis being added
    */
   public void addAnalysis(Analysis analysis)
   {
      jobs.add(analysis);
   }

   /**
    * Method that gets an analysis from the ArrayList
    * 
    * @param index
    *           The index of the analysis being returned
    * @return The analysis that was found on the index
    */
   public Analysis getAnalysis(int index)
   {
      return jobs.get(index);
   }

   /**
    * Method that gets the private list
    * 
    * @return The private variable which is the list
    */

   public ArrayList<Analysis> getJobList()
   {
      return this.jobs;
   }

   /**
    * Method that gets a certain analysis by its name
    * 
    * @param name
    *           The name of the analysis being searched for
    * @exception IOException
    *               This exception is thrown when an analysis with such a name
    *               doesn't exist
    * @return The analysis being searched for
    */

   public Analysis getAnalysis(String name) throws IOException
   {
      for (int i = 0; i < this.jobs.size(); i++)
      {
         if (this.jobs.get(i).getName().equals(name))
         {
            return this.jobs.get(i);
         }
      }
      throw new IOException("An Analysis with this name doesn't exist");
   }

   /**
    * Compares 2 objects of type AnalysisList
    * 
    * @param obj
    *           The second object that's being compared
    * @return Whether the 2 objects are the same or not
    * @exception NullPointerException
    *               The method would throw this type of exception when one of
    *               the objects is null
    */

   public boolean equals(Object obj) throws NullPointerException
   {
      if (!(obj instanceof AnalysisList))
      {
         return false;
      }
      AnalysisList other = (AnalysisList) obj;
      return this.jobs.equals(other.jobs);
   }

   /**
    * Getter method that returns the size of the private list
    * 
    * @return The size of the private list
    */

   public int getSize()
   {
      return jobs.size();
   }

   /**
    * Method that takes the objects from the list and returns them in a string
    * 
    * @return The string from the private list
    */

   public String toString()
   {
      String s = "";
      for (int i = 0; i < jobs.size(); i++)
      {
         s += jobs.get(i) + " ";
      }
      return s;

   }

}
