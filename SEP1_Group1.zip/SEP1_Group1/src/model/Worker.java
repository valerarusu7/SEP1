package model;

/** Description of Worker 
*
* @author Group 1
* @version 1.7 18th December 2018
*/
import java.io.Serializable;
import java.util.ArrayList;

/** Class which represents a single worker/employee */
public class Worker implements Serializable
{
   /** The name of any given worker */
   private String fullName;
   /** The ID of any given worker */
   private String IDnr;
   /** The notes of any given worker */
   private ArrayList<String> notes;
   /** The training of any given worker AKA what are capable of doing */
   private AnalysisList training;

   /**
    * Constructor that initialises the private variables
    * 
    * @param fullName
    *           The value given to the private variable fullName
    * @param IDnr
    *           The value given to the private variable IDnr
    */
   public Worker(String fullName, String IDnr)
   {
      this.fullName = fullName;
      this.IDnr = IDnr;
      this.notes = new ArrayList<>();
      this.training = new AnalysisList();
   }

   /**
    * Constructor that initializes the private variables and sets the training
    * 
    * @param fullName
    *           The value given to the private variable fullName
    * @param IDnr
    *           The value given to the private variable IDnr
    * @param notes
    *           The value given to the private variable notes
    * @param training
    *           The value given to the private variable training
    */
   public Worker(String fullName, String IDnr, ArrayList<String> notes,
         AnalysisList training)
   {
      this.fullName = fullName;
      this.IDnr = IDnr;
      this.notes = new ArrayList<>();
      this.training = training;
   }

   /**
    * Getter method for the IDnr
    * 
    * @return The String value for the IDnr
    */
   public String getIDnr()
   {
      return IDnr;
   }

   /**
    * Mutator method for the IDnr
    * 
    * @param iDnr
    *           The String value for the IDnr
    */
   public void setID(String iDnr)
   {
      this.IDnr = iDnr;
   }

   /**
    * Getter method for the Name
    * 
    * @return The String value for the Name
    */
   public String getFullName()
   {
      return this.fullName;
   }

   /**
    * Mutator method for the name
    * 
    * @param fullName
    *           The String value for the IDnr
    */
   public void setFullName(String fullName)
   {
      this.fullName = fullName;
   }

   /**
    * Getter method for the note
    * 
    * @return The ArrayList value for the note
    */
   public ArrayList<String> getNotes()
   {
      return this.notes;
   }

   /**
    * Setter method for the note
    * 
    * @param notes
    *           The ArrayList value being set for the notes
    */
   public void setNotes(ArrayList<String> notes)
   {
      this.notes = notes;
   }

   /**
    * Method for adding an analysis to the training of the worker
    * 
    * @param analysis
    *           The analysis being added
    */
   public void addToTraining(Analysis analysis)
   {
      this.training.addAnalysis(analysis);
   }

   /**
    * Method for getting the private variable training
    * 
    * @return The private variable
    */
   public AnalysisList getTraining()
   {
      return this.training;
   }

   /**
    * Setter method for the training
    * 
    * @param training
    *           The ArrayList value being set for the training
    */
   public void setTraining(AnalysisList training)
   {
      this.training = training;
   }

   /**
    * Compares 2 objects of type Worker
    * 
    * @param obj
    *           The second object that's being compared
    * @return Whether the 2 objects are the same or not
    * @exception NullPointerException
    *               The method would throw this type of exception when one of
    *               the objects is null
    */
   public boolean equals(Object obj) throws NullPointerException
   {
      if (!(obj instanceof Worker))
      {
         return false;
      }
      Worker other = (Worker) obj;
      return this.fullName.equals(other.fullName)
            && this.IDnr.equals(other.IDnr)
            && this.training.equals(other.training)
            && this.notes.equals(other.notes);
   }

   /**
    * Overwrites the toString method in the String class to display properly the
    * value of the Worker
    * 
    * @return The values of all the private instance variables in a String
    */
   public String toString()
   {
      return fullName + " " + IDnr + " " + training.toString();
   }

}
