package model;

/** Description of AnalysisList 
*
* @author Group 1
* @version 1.0 18 December 2018
*/
import java.io.IOException;
import java.util.ArrayList;

/**
 * Interface which represents the Model
 */
public interface Model
{

   public void createWorker(Worker worker);

   public void createAnalysis(Analysis analysis);

   public void createTraining(Analysis analysis);

   public void createSearchById(Worker worker);

   public void createSearchByName(Worker worker);

   public void createSearchByAnalysis(Worker worker);

   public ArrayList<Worker> getAllWorkers();

   public ArrayList<Analysis> getAllAnalysis();

   public ArrayList<Analysis> getAllTrainings();

   public ArrayList<Worker> getSearchById();

   public ArrayList<Worker> getSearchByName();

   public ArrayList<Worker> getSearchByAnalysis();

   public void setWList() throws ClassNotFoundException;

   public void setAList() throws ClassNotFoundException;

   public void removeWorker(Worker worker);

   public void removeAnalysis(Analysis analysis);

   public Analysis getAnalysis(String name) throws IOException;

   public AnalysisList getTheListOfAnalysis();

   public WorkerList getTheListOfWorkers();

}
