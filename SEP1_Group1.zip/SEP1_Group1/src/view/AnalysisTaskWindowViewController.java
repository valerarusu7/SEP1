package view;

import java.io.IOException;
import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Analysis;

public class AnalysisTaskWindowViewController
{

   private GUI gui;
   private Scene scene;
   private ArrayList<Analysis> training;
   @FXML
   private TableView tableViewAnalysis;
   @FXML
   private TableColumn nameColumn;

   public AnalysisTaskWindowViewController(GUI gui) throws IOException
   {
      this.gui = gui;
      FXMLLoader loader = new FXMLLoader();
      loader.setLocation(getClass().getResource("AnalysisTaskWindow.fxml"));
      loader.setController(this);
      Parent root = loader.load();
      this.scene = new Scene(root);
   }

   @FXML
   public void initialize()
   {
      this.updateItems();
      tableViewAnalysis.setRowFactory(tableView -> {
         TableRow<Analysis> newRow = new TableRow<>();
         return newRow;
      });

      nameColumn.setCellValueFactory(
            new PropertyValueFactory<Analysis, String>("name"));
   }

   public Scene getScene()
   {
      return scene;
   }

   public void ReturnButtonPressed()
   {
      gui.displayAssignTaskViewController();
   }

   public void updateItems()
   {
      this.training = gui.getController().getModel().getAllTrainings();
      tableViewAnalysis.setItems(FXCollections.observableList(training));
      tableViewAnalysis.refresh();
   }

}
