package view;

import java.io.IOException;
import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Worker;

public class SearchViewController
{
   private GUI gui;
   private Scene scene;
   private ArrayList<Worker> workersById, workersByName, workersByAnalysis;
   @FXML
   private TextField Id, name, analysis;
   @FXML
   private TableView nameTable, idTable, analysisTable;
   @FXML
   private TableColumn idnrTableColumnName, nameTableColumnName,
         idnrTableColumnId, nameTableColumnId, idnrTableColumnAnalysis,
         nameTableColumnAnalysis;

   @FXML
   void initialize()
   {
      Id.setText("");
      name.setText("");
      analysis.setText("");
   }

   public SearchViewController(GUI gui) throws IOException
   {
      this.gui = gui;
      FXMLLoader loader = new FXMLLoader();
      loader.setLocation(getClass().getResource("Search.fxml"));
      loader.setController(this);
      Parent root = loader.load();
      this.scene = new Scene(root);
      this.workersById = new ArrayList<Worker>();
      this.workersByName = new ArrayList<Worker>();
      this.workersByAnalysis = new ArrayList<Worker>();
   }

   public void ReturnbuttonPressed()
   {
      gui.displayMainScheduleAdminViewController();
   }

   @FXML
   private void searchByName()
   {
      nameTable.getItems().clear();
      updateItems();
      gui.getController().createSearchByName();
      nameTable.setRowFactory(tableView -> {
         TableRow<Worker> newRow = new TableRow<>();
         return newRow;
      });

      idnrTableColumnName.setCellValueFactory(
            new PropertyValueFactory<Worker, String>("iDnr"));
      nameTableColumnName.setCellValueFactory(
            new PropertyValueFactory<Worker, String>("fullName"));
   }

   @FXML
   private void searchById()
   {
      idTable.getItems().clear();
      updateItems();
      gui.getController().createSearchById();
      idTable.setRowFactory(tableView -> {
         TableRow<Worker> newRow = new TableRow<>();
         return newRow;
      });

      idnrTableColumnId.setCellValueFactory(
            new PropertyValueFactory<Worker, String>("iDnr"));
      nameTableColumnId.setCellValueFactory(
            new PropertyValueFactory<Worker, String>("fullName"));
   }

   @FXML
   private void searchByAnal()
   {
      analysisTable.getItems().clear();
      updateItems();
      gui.getController().createSearchByAnalysis();
      analysisTable.setRowFactory(tableView -> {
         TableRow<Worker> newRow = new TableRow<>();
         return newRow;
      });

      idnrTableColumnAnalysis.setCellValueFactory(
            new PropertyValueFactory<Worker, String>("iDnr"));
      nameTableColumnAnalysis.setCellValueFactory(
            new PropertyValueFactory<Worker, String>("fullName"));
   }

   public Scene getScene()
   {
      return scene;
   }

   public void updateItems()
   {
      this.workersByName = gui.getController().getModel().getSearchByName();
      this.workersByAnalysis = gui.getController().getModel()
            .getSearchByAnalysis();
      this.workersById = gui.getController().getModel().getSearchById();
      nameTable.setItems(FXCollections.observableList(workersByName));
      nameTable.refresh();
      analysisTable.setItems(FXCollections.observableList(workersByAnalysis));
      analysisTable.refresh();
      idTable.setItems(FXCollections.observableList(workersById));
      idTable.refresh();
   }

   public String getId()
   {
      return Id.getText();
   }

   public String getName()
   {
      return name.getText();
   }

   public String getAnalysis()
   {
      return analysis.getText();
   }

}
