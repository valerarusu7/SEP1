package model;

import java.util.ArrayList;

public class ModelManager implements Model {
    private WorkerList workerList;
    private AnalysisList analysisList;


    public ModelManager(){

    }
    public void createWorker(Worker worker) {
        workerList.addWorker(worker);
    }

    public void createAnalysis(Analysis analysis) {
        analysisList.addWorker(analysis);
    }

    public ArrayList<Worker> getAllWorkers() {
        return workerList.getAll();
    }

    public void setWorkerList(WorkerList workerList){
        this.workerList = workerList;
    }

    public void setAnalysisList(AnalysisList analysisList){
        this.analysisList = analysisList;
    }

    public ArrayList<Analysis> getAllAnalysis() {
        return analysisList.getAll();
    }
}
