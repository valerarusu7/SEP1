package model;

import java.util.ArrayList;

public interface Model {

    public void createWorker(Worker worker);

    public void removeWorker(Worker worker);

    public void createAnalysis(Analysis analysis);

    public ArrayList<Worker> getAllWorkers();

    public ArrayList<Analysis> getAllAnalysis();

}
