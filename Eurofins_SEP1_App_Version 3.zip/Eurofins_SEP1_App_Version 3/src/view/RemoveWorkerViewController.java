package view;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import com.sun.corba.se.spi.orbutil.threadpool.Work;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import model.Worker;

public class RemoveWorkerViewController
{
   private ArrayList<Worker> workerList;
   private GUI gui;
   private Scene scene;
   @FXML private TableView tableView;
   @FXML private TableColumn idColumn;
   @FXML private TableColumn nameColumn;

   public RemoveWorkerViewController(GUI gui) throws IOException {
      this.gui=gui;
      FXMLLoader loader = new FXMLLoader();
      loader.setLocation(getClass().getResource("Remove_Worker.fxml"));
      loader.setController(this);

      Parent root = loader.load();
      this.scene = new Scene(root);
      this.workerList = new ArrayList<>();

   }

   @FXML void initialize() {
      tableView.setRowFactory(tableView -> {
         TableRow<Worker> newRow = new TableRow<>();
         return newRow;
      });

      idColumn.setCellValueFactory(new PropertyValueFactory<Worker, String>("iDnr"));
      nameColumn.setCellValueFactory(new PropertyValueFactory<Worker, String>("fullName"));
   }

   public void ReturnbuttonPressed() {
      gui.displayManageWorkersViewController();
   }

   public Scene getScene(){
      return scene;
   }

   public void updateItems(){
      this.workerList = gui.getController().getModel().getAllWorkers();
      tableView.setItems(FXCollections.observableList(workerList));
      tableView.refresh();
   }

   @FXML private void RemoveButtonPressed()
   {
      tableView.getItems().removeAll(tableView.getSelectionModel().getSelectedItems());
      gui.getController().getView().getWorkerListViewController().updateItems();
      gui.getController().getView().getRemoveWorkerViewController().updateItems();
   }

}





