package view;

import java.io.IOException;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Worker;

public class WorkerListViewController {
    private  ArrayList<Worker> workerList;
    private Scene scene;
    private GUI gui;
    @FXML private TableView tableView;
    @FXML private TableColumn idColumn;
    @FXML private TableColumn nameColumn;

    public WorkerListViewController(GUI gui) throws IOException {
        this.gui = gui;
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("WorkerList.fxml"));
        loader.setController(this);
        Parent root = loader.load();
        this.scene = new Scene(root);
        this.workerList = new ArrayList<>();
    }

    @FXML
    private void initialize() {
        tableView.setRowFactory(tableView -> {
            TableRow<Worker> newRow = new TableRow<>();
            return newRow;
        });

        idColumn.setCellValueFactory(new PropertyValueFactory<Worker, String>("iDnr"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<Worker, String>("fullName"));
    }

    @FXML
    private void ReturnbuttonPressed() {
        gui.displayManageWorkersViewController();
    }

    public Scene getScene() {
        return scene;
    }

    public void updateItems(){
        this.workerList = gui.getController().getModel().getAllWorkers();
        tableView.setItems(FXCollections.observableList(workerList));
        tableView.refresh();
    }

}

