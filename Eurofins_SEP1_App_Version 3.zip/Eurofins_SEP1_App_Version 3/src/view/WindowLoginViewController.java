package view;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;

public class WindowLoginViewController
{
   private GUI gui;
   private Scene scene;
   @FXML private PasswordField passwordField;
   @FXML private TextField usernameField;
   @FXML private Label lblStatus;

   public WindowLoginViewController(GUI gui) throws IOException {
      this.gui=gui;
      FXMLLoader loader = new FXMLLoader();
      loader.setLocation(getClass().getResource("WindowLogin.fxml"));
      loader.setController(this);

      Parent root = loader.load();
      this.scene = new Scene(root);
   }

   @FXML void loginButtonPressed()  {
      if (passwordField.getText().equals("") && usernameField.getText().equals("")) {
   gui.displayMainScheduleAdminViewController();
   } else {
      lblStatus.setText("Login Failed");
      usernameField.clear();
      passwordField.clear();
          }
   }

   public Scene getScene(){
      return scene;
   }

}
