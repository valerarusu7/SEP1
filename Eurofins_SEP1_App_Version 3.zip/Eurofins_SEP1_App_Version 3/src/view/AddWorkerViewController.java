package view;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import model.WorkerList;

public class AddWorkerViewController
{
   @FXML private TextField fullName;
   @FXML private TextField idWorker;
   private WorkerList list;
   private Scene scene;
   private GUI gui;

   public AddWorkerViewController(GUI gui) throws IOException {
      this.gui=gui;
      FXMLLoader loader = new FXMLLoader();
      loader.setLocation(getClass().getResource("AddWorker.fxml"));
      loader.setController(this);
      Parent root = loader.load();
      this.scene = new Scene(root);
   }

   public AddWorkerViewController(){
      this.list = new WorkerList();
   }

   public String getFullName() {
      return  fullName.getText();
   }
   public String getIdWorker() {
      return idWorker.getText();
   }

   public void initialize() {
      fullName.setText("");
      idWorker.setText("");
   }

   public void ReturnbuttonPressed()  {
      gui.displayManageWorkersViewController();
   }

   public Scene getScene(){
      return scene;
   }

   @FXML private void addWorker(){
      gui.getController().createWorker();
      fullName.setText("");
      idWorker.setText("");
      gui.getController().getView().getWorkerListViewController().updateItems();
      gui.getController().getView().displayWorkerListViewController();
      gui.getController().getView().getRemoveWorkerViewController().updateItems();
   }

}
