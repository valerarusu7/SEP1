package view;

import java.io.IOException;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Analysis;

public class AnalysisListViewController {

    private ArrayList<Analysis> analysisList;
    private GUI gui;
    private Scene scene;
    @FXML private TableView tableView;
    @FXML private TableColumn analysisName;

    public AnalysisListViewController(GUI gui) throws IOException {
        this.gui = gui;
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("AnalysisList.fxml"));
        loader.setController(this);
        Parent root = loader.load();
        this.scene = new Scene(root);
        this.analysisList = new ArrayList<>();
    }

    @FXML
    private void initialize() {
        tableView.setRowFactory(tableView -> {
            TableRow<Analysis> newRow = new TableRow<>();
            return newRow;
        });

        analysisName.setCellValueFactory(new PropertyValueFactory<Analysis, String>("analysisName"));
    }

    @FXML
    private void ReturnbuttonPressed()  {
        gui.displayManageAnalysisViewController();
    }


    public Scene getScene(){
        return scene;
    }

    public void updateItems(){
        this.analysisList = gui.getController().getModel().getAllAnalysis();
        tableView.setItems(FXCollections.observableList(analysisList));
        tableView.refresh();
    }

}
