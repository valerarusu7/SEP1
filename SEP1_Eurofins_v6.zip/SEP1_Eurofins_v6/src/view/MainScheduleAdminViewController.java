package view;

import java.io.IOException;
import java.time.LocalDate;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;

public class MainScheduleAdminViewController
{
   private GUI gui;
   private Scene scene;
   private LocalDate localDate;
   @FXML
   public Label firstDay, secondDay, thirdDay, fourthDay, fifthDay, sixthDay,
         seventhDay;
   @FXML
   public Label Day, DayTwo, DayThree, DayFour, DayFive, DaySix, DaySeven;

   public MainScheduleAdminViewController(GUI gui) throws IOException
   {
      this.gui = gui;
      FXMLLoader loader = new FXMLLoader();
      loader.setLocation(getClass().getResource("MainScheduleAdmin.fxml"));
      loader.setController(this);
      Parent root = loader.load();
      this.scene = new Scene(root);
      this.localDate = LocalDate.now();
      this.setDates();
      this.setNameDates();
   }

   @FXML
   void initialize()
   {
   }

   @FXML
   void goForwardInWeekPressed()
   {
      this.localDate = this.localDate.plusDays(7);
      this.setDates();
      this.setNameDates();
   }

   @FXML
   void goBackwardInWeekPressed()
   {
      this.localDate = this.localDate.minusDays(7);
      this.setDates();
      this.setNameDates();
   }

   public void setDates()
   {

      firstDay.setText(this.localDate.getDayOfMonth() + "/"
              + this.localDate.getMonth().getValue() + "/"
              + this.localDate.getYear());
      secondDay.setText(this.localDate.plusDays(1).getDayOfMonth() + "/"
              + this.localDate.plusDays(1).getMonth().getValue() + "/"
              + this.localDate.plusDays(1).getYear());
      thirdDay.setText(this.localDate.plusDays(2).getDayOfMonth() + "/"
              + this.localDate.plusDays(2).getMonth().getValue() + "/"
              + this.localDate.plusDays(2).getYear());
      fourthDay.setText(this.localDate.plusDays(3).getDayOfMonth() + "/"
              + this.localDate.plusDays(3).getMonth().getValue() + "/"
              + this.localDate.plusDays(3).getYear());
      fifthDay.setText(this.localDate.plusDays(4).getDayOfMonth() + "/"
              + this.localDate.plusDays(4).getMonth().getValue() + "/"
              + this.localDate.plusDays(4).getYear());
      sixthDay.setText(this.localDate.plusDays(5).getDayOfMonth() + "/"
              + this.localDate.plusDays(5).getMonth().getValue() + "/"
              + this.localDate.plusDays(5).getYear());
      seventhDay.setText(this.localDate.plusDays(6).getDayOfMonth() + "/"
              + this.localDate.plusDays(6).getMonth().getValue() + "/"
              + this.localDate.plusDays(6).getYear());
   }

   public void setNameDates()
   {
      Day.setText(localDate.getDayOfWeek().toString());
      DayTwo.setText(localDate.plusDays(1).getDayOfWeek().toString());
      DayThree.setText(localDate.plusDays(2).getDayOfWeek().toString());
      DayFour.setText(localDate.plusDays(3).getDayOfWeek().toString());
      DayFive.setText(localDate.plusDays(4).getDayOfWeek().toString());
      DaySix.setText(localDate.plusDays(5).getDayOfWeek().toString());
      DaySeven.setText(localDate.plusDays(6).getDayOfWeek().toString());
   }



   public void signOutbuttonPressed()
   {
      gui.displayWindowLoginViewController();
   }

   public void AssignButtonPressed()
   {
      gui.displayAssignTaskViewController();
   }

   public void manageAnalysisbuttonPressed()
   {
      gui.displayManageAnalysisViewController();
   }

   public void manageWorkersbuttonPressed()
   {
      gui.displayManageWorkersViewController();
   }

   public void SearchbuttonPressed()
   {
      gui.displaySearchViewController();
   }

   public Scene getScene()
   {
      return scene;
   }
}
