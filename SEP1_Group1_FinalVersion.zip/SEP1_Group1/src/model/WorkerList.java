package model;

/** Description of WorkerList 
*
* @author Group 1
* @version 2.0 18th December 2018
*/
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

/** Class which represents multiple workers/employees */
public class WorkerList implements Serializable
{
   /** The collection of every Worker that has been added */
   private ArrayList<Worker> list;

   /**
    * Constructor that initialises the ArrayList
    */
   public WorkerList()
   {
      this.list = new ArrayList<>();
   }

   /**
    * Method that adds the given worker to the list
    * 
    * @param worker
    *           The variable used to add to the list
    */
   public void addWorker(Worker worker)
   {
      list.add(worker);
   }

   /**
    * Method that removes the given worker from the list
    * 
    * @param worker
    *           The variable used to remove to the list
    */
   public void removeWorker(Worker worker)
   {
      list.remove(worker);
   }

   /**
    * Method that adds the given worker to the list
    * 
    * @return The whole list of workers
    */
   public ArrayList<Worker> getAll()
   {
      return list;
   }

   /**
    * Method that adds the given worker to the list
    * 
    * @param index
    *           The index of the worker wanted
    * @return A certain worker taken by the index
    */
   public Worker getWorker(int index)
   {
      return list.get(index);
   }

   /**
    * Method that gets the number of workers by the given name
    * 
    * @param name
    *           The name of the workers wanted
    * @return The amount of workers
    */
   public int getNumberOfWorkersByName(String name)
   {
      int count = 0;
      for (int i = 0; i <= list.size(); i++)
      {
         if (list.get(i).getFullName().equals(name))
            count++;
      }
      return count;
   }

   /**
    * Method that gets the workers by the given name
    * 
    * @param name
    *           The name of the workers wanted
    * @return The workers
    * @exception IOException
    *               This exception is thrown when there exist no workers with
    *               the given name
    */
   public ArrayList<Worker> getWorkersByName(String name) throws IOException
   {
      ArrayList<Worker> listByName = new ArrayList<Worker>();
      for (int i = 0; i <= list.size(); i++)
      {
         if (list.get(i).getFullName().equals(name))
         {
            listByName.add(list.get(i));
         }
      }
      if (listByName.size() == 0)
         throw new IOException();
      else
         return listByName;
   }

   /**
    * Method that gets the number of workers by the given IDnr
    * 
    * @param IDnr
    *           The IDnr of the workers wanted
    * @return The amount of workers
    */
   public int getNumberOfWorkersByIDnr(String IDnr)
   {
      int count = 0;
      for (int i = 0; i <= list.size(); i++)
      {
         if (list.get(i).getIDnr().equals(IDnr))
            count++;
      }
      return count;
   }

   /**
    * Method that gets the workers by the given ID
    * 
    * @param IDnr
    *           The ID of the workers wanted
    * @return The workers
    * @exception IOException
    *               This exception is thrown when there exist no workers with
    *               the given ID
    */
   public ArrayList<Worker> getWorkersByIDnr(String IDnr) throws IOException
   {
      ArrayList<Worker> listByIDnr = new ArrayList<Worker>();
      for (int i = 0; i <= list.size(); i++)
      {
         if (list.get(i).getIDnr().equals(IDnr))
         {
            listByIDnr.add(list.get(i));
         }
      }
      if (listByIDnr.size() == 0)
         throw new IOException();
      else
         return listByIDnr;
   }

   /**
    * Method that gets the number of workers by the given analysis name
    * 
    * @param name
    *           The name of the analysis of the workers wanted
    * @return The amount of workers
    */
   public int getNumberOfWorkersByAnalysis(String name)
   {
      int count = 0;
      for (int i = 0; i <= list.size(); i++)
      {
         for (int j = 0; j <= list.get(i).getTraining().getJobList()
               .size(); j++)
         {
            for (int z = 0; z <= list.get(i).getTraining().getJobList()
                  .size(); z++)
               if (list.get(i).getTraining().getJobList().get(j).getName()
                     .equals(name))
                  count++;
         }
      }
      return count;
   }

   /**
    * Method that gets the workers by the given analysis name
    * 
    * @param name
    *           The analysis name
    * @return The workers with training in the given analysis
    * @exception IOException
    *               This exception is thrown when there exist no workers with
    *               the given analysis
    */
   public ArrayList<Worker> getWorkersByAnalysis(String name) throws IOException
   {
      ArrayList<Worker> listByAnalysis = new ArrayList<Worker>();
      for (int i = 0; i <= list.size(); i++)
      {
         for (int j = 0; j <= list.get(i).getTraining().getJobList()
               .size(); j++)
         {
            for (int z = 0; z <= list.get(i).getTraining().getJobList()
                  .size(); z++)
               if (list.get(i).getTraining().getJobList().get(j).getName()
                     .equals(name))
                  listByAnalysis.add(list.get(i));
         }
      }
      if (listByAnalysis.size() == 0)
         throw new IOException();
      else
         return listByAnalysis;
   }

   /**
    * Method that gets a worker by the given name
    * 
    * @param name
    *           The name of the worker wanted
    * @return The worker
    */
   public Worker getWorkerByName(String name)
   {
      for (int i = 0; i <= list.size(); i++)
      {
         if (list.get(i).getFullName().equals(name))
            return list.get(i);
      }
      return null;
   }

   /**
    * Method that gets a worker by the given ID
    * 
    * @param ID
    *           The ID of the worker wanted
    * @return The worker
    */
   public Worker getWorkerByID(String ID)
   {
      for (int i = 0; i <= list.size(); i++)
      {
         if (list.get(i).getIDnr().equals(ID))
            return list.get(i);
      }
      return null;
   }

   /**
    * Getter method for the notes of a worker
    * 
    * @param name
    *           The name of the worker whose notes are returned
    * @return The workers notes
    */
   public ArrayList<String> getNotesByName(String name)
   {
      for (int i = 0; i <= list.size(); i++)
      {
         if (list.get(i).getFullName().equals(name))
            this.list.get(i).getNotes();
      }
      return null;
   }

   /**
    * Getter method for the training of a worker
    * 
    * @param name
    *           The name of the worker whose training are returned
    * @return The workers training
    */
   public AnalysisList getTrainingByName(String name)
   {
      for (int i = 0; i <= list.size(); i++)
      {
         if (list.get(i).getFullName().equals(name))
            this.list.get(i).getTraining();
      }
      return null;
   }

   /**
    * Getter method for the size of the workerlist
    * 
    * @return The workerlist's size
    */
   public int getSize()
   {
      return list.size();
   }

}
