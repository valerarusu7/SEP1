package model;

/** Description of MyDate 
*
* @author Group 1
* @version 2.0 September 2018
*/
import java.util.Calendar;
import java.util.GregorianCalendar;

/** Class which represents a date */
public class MyDate
{
   /** The day,month and year of the date */
   private int day, month, year;

   /**
    * Constructor that initialises the private variables with todays values
    */
   public MyDate()
   {
      Calendar now = GregorianCalendar.getInstance();
      this.day = now.get(Calendar.DAY_OF_MONTH);
      this.month = now.get(Calendar.MONTH) + 1;
      this.year = now.get(Calendar.YEAR);
   }

   /**
    * Getter method for the day of the date
    * 
    * @return The MyDate value
    */
   public int getDay()
   {
      return this.day;
   }

   /**
    * Getter method for the month of the date
    * 
    * @return The MyDate value
    */
   public int getMonth()
   {
      return this.month;
   }

   /**
    * Getter method for the year of the date
    * 
    * @return The MyDate value
    */
   public int getYear()
   {
      return this.year;
   }

   /**
    * Overwrites the toString method in the String class to display properly the
    * value of the String
    * 
    * @return The private instance variables
    */
   public String toString()
   {
      return this.day + "/" + this.month + "/" + this.year;
   }

   /**
    * Compares 2 objects of type MyDate
    * 
    * @param obj
    *           The second object that's being compared
    * @return Whether the 2 objects are the same or not
    * @exception NullPointerException
    *               The method would throw this type of exception when one of
    *               the objects is null
    */
   public boolean equals(Object obj)
   {
      if (!(obj instanceof MyDate))
      {
         return false;
      }
      MyDate other = (MyDate) obj;
      return this.day == other.day && this.month == other.month
            && this.year == other.year;
   }
}