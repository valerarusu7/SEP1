package model;

/** Description of Task 
*
* @author Group 1
* @version 1.0 18th December 2018
*/
import java.io.IOException;
import java.io.Serializable;

/**
 * Class which represents a single task which can be either a Job or a Vacation
 */
public abstract class Task implements Serializable
{
   /** The worker doing the task */
   private Worker who;
   /** The Date of the task */
   private MyDate start;

   /**
    * Constructor that initialises the private variables
    * 
    * @param who
    *           The value given to the private variable who
    * @param start
    *           The value given to the private variable start
    */
   public Task(Worker who, MyDate start)
   {
      this.who = who;
      this.start = start;
   }

   /**
    * Constructor that initialises the private variables (Sets the worker as
    * null for template reasons)
    * 
    * @param start
    *           The value given to the private variable start
    */
   public Task(MyDate start)
   {
      this.who = null;
      this.start = start;
   }

   /**
    * Getter method for the Worker
    * 
    * @return The String value for the IDnr
    * @exception IOException
    *               This exception is thrown when the worker is null for
    *               template purposes
    */
   public Worker getWorker() throws IOException
   {
      if (this.who.equals(null))
         throw new IOException(
               "There is no worker assigned to this task, it's probably a template");
      else
         return this.who;
   }

   /**
    * Getter method for the start of the task
    * 
    * @return The MyDate value
    */
   public MyDate getStart()
   {
      return this.start;
   }

   /**
    * Setter method for the worker
    * 
    * @param who
    *           The worker being assigned the task
    */
   public void setWorker(Worker who)
   {
      this.who = who;
   }

   /**
    * Setter method for the start of the task
    * 
    * @param start
    *           The date being assigned to the task
    */
   public void setStart(MyDate start)
   {
      this.start = start;
   }

   /**
    * Compares 2 objects of type Task
    * 
    * @param obj
    *           The second object that's being compared
    * @return Whether the 2 objects are the same or not
    * @exception NullPointerException
    *               The method would throw this type of exception when one of
    *               the objects is null
    */
   public boolean equals(Object obj) throws NullPointerException
   {
      if (!(obj instanceof Task))
      {
         return false;
      }
      Task other = (Task) obj;
      return this.who.equals(other.who) && this.start.equals(other.start);
   }
}
