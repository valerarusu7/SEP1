package model;

/** Description of ModelManager 
*
* @author Group 1
* @version 2.0 September 2018
*/
import java.io.IOException;
import java.util.ArrayList;

/**
 * Class which represents the ModelManager which implements the Model interface
 */
public class ModelManager implements Model
{
   /** The master WorkerList */
   private WorkerList workerList;
   /** The search lists */
   private WorkerList searchById, searchByName, searchByAnalysis;
   /** The master AnalysisList */
   private AnalysisList analysisList;
   /** The list used to represent and add the training of a worker */
   private AnalysisList training;
   /** The bin file used for storing workers */
   private FileManager Workers;
   /** The bin file used for storing analysis */
   private FileManager Analysis;
   /** The bin file used for storing a template */
   private FileManager TemplateS;
   /** The bin file used for storing a template */
   private FileManager TemplateL;
   /** The bin file used for storing the master schedule */
   private FileManager ScheduleM;

   /**
    * Constructor that initialises the private variables and sets the WorkerList
    * and the AnalysisList
    * 
    * @exception ClassNotFoundException
    *               This exception is thrown when the WorkerList or the
    *               AnalysisList can't be set
    */
   public ModelManager() throws ClassNotFoundException
   {
      this.Workers = new FileManager("Workers.bin");
      this.Analysis = new FileManager("Analysis.bin");
      this.TemplateS = new FileManager("TemplateS.bin");
      this.TemplateL = new FileManager("TemplateL.bin");
      this.ScheduleM = new FileManager("ScheduleM.bin");
      this.training = new AnalysisList();
      this.searchById = new WorkerList();
      this.searchByName = new WorkerList();
      this.searchByAnalysis = new WorkerList();
      this.setWList();
      this.setAList();
   }

   /**
    * Method that creates a worker in the master WorkerList and rewrites the
    * whole bin file with the new object
    * 
    * @param worker
    *           The worker being added
    */
   public void createWorker(Worker worker)
   {
      try
      {
         workerList.addWorker(worker);
         Workers.writeToBin("Workers.bin", workerList);
      }
      catch (IOException e)
      {

      }
   }

   /**
    * Method that creates an analysis in the master AnalysisList and rewrites
    * the whole bin file with the new object
    * 
    * @param analysis
    *           The analysis being added
    */
   public void createAnalysis(Analysis analysis)
   {
      try
      {
         analysisList.addAnalysis(analysis);
         Analysis.writeToBin("Analysis.bin", analysisList);
      }
      catch (IOException e)
      {

      }
   }

   /**
    * Method that creates a worker in the searchById
    * 
    * @param worker
    *           The worker being added
    */
   public void createSearchById(Worker worker)
   {
      this.searchById.addWorker(worker);
   }

   /**
    * Method that creates a worker in the searchByName
    * 
    * @param worker
    *           The worker being added
    */
   public void createSearchByName(Worker worker)
   {
      this.searchByName.addWorker(worker);
   }

   /**
    * Method that creates a worker in the searchByAnalysis
    * 
    * @param worker
    *           The worker being added
    */
   public void createSearchByAnalysis(Worker worker)
   {
      this.searchByAnalysis.addWorker(worker);
   }

   /**
    * Method that creates an analysis in training
    * 
    * @param analysis
    *           The analysis being added
    */
   public void createTraining(Analysis analysis)
   {
      training.addAnalysis(analysis);
   }

   /**
    * Getter method for the workers from the master WorkerList
    * 
    * @return The workers inside the master WorkerList
    */
   public ArrayList<Worker> getAllWorkers()
   {
      return workerList.getAll();
   }

   /**
    * Setter method for the master workerList
    * 
    * @param workerList
    *           The value given to the master workerList
    */
   public void setWorkerList(WorkerList workerList)
   {
      this.workerList = workerList;
   }

   /**
    * Setter method for the master analysisList
    * 
    * @param analysisList
    *           The value given to the master analysisList
    */
   public void setAnalysisList(AnalysisList analysisList)
   {
      this.analysisList = analysisList;
   }

   /**
    * Getter method for the search WorkerListById
    * 
    * @return The searchByID workers
    */
   public ArrayList<Worker> getSearchById()
   {
      return this.searchById.getAll();
   }

   /**
    * Getter method for the master WorkerListByName
    * 
    * @return The searchByName workers
    */
   public ArrayList<Worker> getSearchByName()
   {
      return this.searchByName.getAll();
   }

   /**
    * Getter method for the master WorkerListByAnalysis
    * 
    * @return The searchByAnalysis workers
    */
   public ArrayList<Worker> getSearchByAnalysis()
   {
      return this.searchByAnalysis.getAll();
   }

   /**
    * Getter method for the master AnalysisList analysis
    * 
    * @return The analysis inside the master AnalysisList
    */
   public ArrayList<Analysis> getAllAnalysis()
   {
      return analysisList.getAll();
   }

   /**
    * Getter method for the master training list analysis
    * 
    * @return The analysis inside the master training list
    */
   public ArrayList<Analysis> getAllTrainings()
   {
      return training.getJobList();
   }

   /**
    * Setter method for the master WorkerList that loads from the bin files
    * 
    * @exception ClassNotFoundException
    *               This exception is thrown when the object that's being read
    *               is unknown
    */
   public void setWList() throws ClassNotFoundException
   {
      this.workerList = new WorkerList();
      try
      {
         for (int i = 0; i < ((WorkerList) Workers.loadFromBin())
               .getSize(); i++)
         {
            workerList
                  .addWorker(((WorkerList) Workers.loadFromBin()).getWorker(i));
         }
      }
      catch (IOException e)
      {

      }
   }

   /**
    * Setter method for the master AnalysisList that loads from the bin files
    * 
    * @exception ClassNotFoundException
    *               This exception is thrown when the object that's being read
    *               is unknown
    */
   public void setAList() throws ClassNotFoundException
   {
      this.analysisList = new AnalysisList();
      try
      {
         for (int i = 0; i < ((AnalysisList) Analysis.loadFromBin())
               .getSize(); i++)
         {
            analysisList.addAnalysis(
                  ((AnalysisList) Analysis.loadFromBin()).getAnalysis(i));
         }
      }
      catch (IOException e)
      {

      }
   }

   /**
    * Method for the master WorkerList that removes a worker then rewrites the
    * whole master WorkerList to bin
    */
   public void removeWorker(Worker worker)
   {
      try
      {
         workerList.removeWorker(worker);
         Workers.writeToBin("Workers.bin", workerList);
      }
      catch (IOException e)
      {

      }
   }

   /**
    * Method for the master AnalysisList that removes an analysis then rewrites
    * the whole master AnalysisList to bin
    */
   public void removeAnalysis(Analysis analysis)
   {
      try
      {
         analysisList.removeAnalysis(analysis);
         Analysis.writeToBin("Analysis.bin", analysisList);
      }
      catch (IOException e)
      {

      }
   }

   /**
    * Getter method for the master AnalysisList that gets a specific analysis
    * with the given name
    * 
    * @param name
    *           The analysis being searched for
    * @return The analysis being searched for
    * @exception IOException
    *               This exception is thrown when the analysis is not found in
    *               the master AnalysisList
    */
   public Analysis getAnalysis(String name) throws IOException
   {
      return analysisList.getAnalysis(name);
   }

   /**
    * Getter method for the master AnalysisList
    * 
    * @return The master AnalysisList
    */
   public AnalysisList getTheListOfAnalysis()
   {
      return analysisList;
   }

   /**
    * Getter method for the master WorkerList
    * 
    * @return The master WorkerList
    */
   public WorkerList getTheListOfWorkers()
   {
      return workerList;
   }

}
