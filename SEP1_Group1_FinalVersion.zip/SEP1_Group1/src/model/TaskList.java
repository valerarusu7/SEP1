package model;

/** Description of TaskList 
*
* @author Group 1
* @version 1.0 18th December 2018
*/
import java.io.Serializable;
import java.util.ArrayList;

/**
 * Class which represents multiple tasks which can be either Jobs or Vacations
 */
public class TaskList implements Serializable
{
   /** The whole task list */
   private ArrayList<Task> tasks;

   /**
    * Constructor that initialises the private variables
    */
   public TaskList()
   {
      this.tasks = new ArrayList<Task>();
   }

   /**
    * Constructor that initialises the private variables for a template
    * 
    * @param template
    *           The value given to the private variable tasks (for template
    *           purposes)
    */
   public TaskList(ArrayList<Task> template)
   {
      this.tasks = template;
   }

   /**
    * Setter method for the tasks
    * 
    * @param template
    *           The template being loaded
    */
   public void setTasks(ArrayList<Task> template)
   {
      this.tasks = template;
   }

   /**
    * Getter method for the private variable tasks
    * 
    * @return The private variable tasks
    */
   public ArrayList<Task> getTasks()
   {
      return this.tasks;
   }

   /**
    * Compares 2 objects of type TaskList
    * 
    * @param obj
    *           The second object that's being compared
    * @return Whether the 2 objects are the same or not
    * @exception NullPointerException
    *               The method would throw this type of exception when one of
    *               the objects is null
    */
   public boolean equals(Object obj) throws NullPointerException
   {
      if (!(obj instanceof TaskList))
      {
         return false;
      }
      TaskList other = (TaskList) obj;
      return this.tasks.equals(other.tasks);
   }
}