package model;

import java.io.IOException;

/** Description of Vacation 
*
* @author Group 1
* @version 1.0 18th December 2018
*/
/** Class which represents a vacation */
public class Vacation extends Task
{
   /** The type of the vacation */
   private String type;
   /**
    * The status of the vacation which can be either
    * Approved/Pending/Disapproved
    */
   private String status;
   /** The end date of the vacation */
   private MyDate end;

   /**
    * Constructor that initialises the private variables where status is set to
    * "Pending" always
    * 
    * @param who
    *           The value given to the private variable who in the super
    *           constructor
    * @param start
    *           The value given to the private variable start in the super
    *           constructor
    * @param end
    *           The value given to the private variable end
    * @param type
    *           The value given to the private variable type
    */
   public Vacation(Worker who, String type, MyDate start, MyDate end)
   {
      super(who, start);
      this.type = type;
      this.end = end;
      this.status = "Pending";
   }

   /**
    * Getter method for the type of the vacation
    * 
    * @return The String value for the type of the vacation
    */
   public String getType()
   {
      return this.type;
   }

   /**
    * Getter method for the status of the vacation
    * 
    * @return The String value for the status of the vacation
    */
   public String getStatus()
   {
      return this.status;
   }

   /**
    * Getter method for the end of the vacation
    * 
    * @return The MyDate object for the end of the vacation
    */
   public MyDate getEnd()
   {
      return this.end;
   }

   /**
    * Setter method for the status of the vacation
    * 
    * @param status
    *           The String value for the status of the vacation
    */
   public void setStatus(String status)
   {
      this.status = status;
   }

   /**
    * Setter method for the type of the vacation
    * 
    * @param type
    *           The String value for the type of the vacation
    */
   public void setType(String type)
   {
      this.type = type;
   }

   /**
    * Setter method for the end of the vacation
    * 
    * @param end
    *           The MyDate object used for the end of the vacation
    */
   public void setEnd(MyDate end)
   {
      this.end = end;
   }

   /**
    * Compares 2 objects of type Vacation
    * 
    * @param obj
    *           The second object that's being compared
    * @return Whether the 2 objects are the same or not
    * @exception NullPointerException
    *               The method would throw this type of exception when one of
    *               the objects is null
    */
   public boolean equals(Object obj) throws NullPointerException
   {
      if (super.equals(obj))
      {
         Vacation other = (Vacation) obj;
         return this.type.equals(other.type) && this.status.equals(other.status)
               && this.end.equals(other.end);
      }
      else
         return false;
   }

}
