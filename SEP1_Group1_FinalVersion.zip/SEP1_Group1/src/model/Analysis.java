package model;

/** Description of Analysis 
*
* @author Group 1
* @version 1.0 15th December 2018
*/
import java.io.Serializable;

/** Class which represents a single analysis */
public class Analysis implements Serializable
{
   /** The name of any given Analysis */
   private String name;

   /**
    * Constructor that initialises the private variable name
    * 
    * @param name
    *           The value given to the private variable name
    */
   public Analysis(String name)
   {
      this.name = name;
   }

   /**
    * Getter method for the single private variable
    * 
    * @return The name of the Analysis
    */
   public String getName()
   {
      return this.name;
   }

   /**
    * Setter method for the single private variable
    * 
    * @param name
    *           The value given to the private variable name
    */
   public void setName(String name)
   {
      this.name = name;
   }

   /**
    * Compares 2 objects of type Analysis
    * 
    * @param obj
    *           The second object that's being compared
    * @return Whether the 2 objects are the same or not
    * @exception NullPointerException
    *               The method would throw this type of exception when one of
    *               the objects is null
    */
   public boolean equals(Object obj) throws NullPointerException
   {
      if (!(obj instanceof Analysis))
      {
         return false;
      }
      Analysis other = (Analysis) obj;
      return this.name.equals(other.name);
   }

   /**
    * Checks to see if any special characters were used in the inputString local
    * variable
    * 
    * @param inputString
    *           A string which is to be checked within the method
    * @return Whether the inputString contains any special characters or not
    */
   public boolean isLegal(String inputString)
   {
      String specialCharacters = " !#$%&'()*+,-./:;<=>?@[]^_`{|}~0123456789";
      String[] strlCharactersArray = new String[inputString.length()];
      for (int i = 0; i < inputString.length(); i++)
      {
         strlCharactersArray[i] = Character.toString(inputString.charAt(i));
      }
      int count = 0;
      for (int i = 0; i < strlCharactersArray.length; i++)
      {
         if (specialCharacters.contains(strlCharactersArray[i]))
         {
            count++;
         }
      }
      if (inputString != null && count == 0)
      {
         return true;
      }
      else
      {
         return false;
      }
   }

   /**
    * Overwrites the toString method in the String class to display properly the
    * value of the String
    * 
    * @return The private instance variable
    */
   public String toString()
   {
      return getName();
   }

}
