package model;

/** Description of FileManager 
*
* @author Group 1
* @version 1.0 15th December 2018
*/
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

/** Class which controls saving and loading from files */
public class FileManager
{
   /** The name of the file */
   private String filename;
   /** The actual file being open/created */
   private File file;

   /**
    * Constructor that initialises the private variable filename and
    * creates/opens the file
    * 
    * @param filename
    *           The value given to the private variable name
    */
   public FileManager(String filename)
   {
      this.filename = filename;
      this.file = new File(filename);
   }

   /**
    * Method that depending on what the filename local variable is writes to a
    * certain file
    * 
    * @param filename
    *           The variable which shows to which file to write to
    * @param obj
    *           The object that is to be written to the file
    * @exception IOException
    *               The method throws an exception with an error message
    *               depending on the case saying that the object local variable
    *               is being put into the wrong file or that the filename isn't
    *               spelled correctly
    */
   public void writeToBin(String filename, Object obj) throws IOException
   {
      switch (filename)
      {
         case "Workers.bin":
         {
            FileOutputStream fos = new FileOutputStream(file);
            ObjectOutputStream out = null;
            out = new ObjectOutputStream(fos);
            if (obj instanceof WorkerList)
            {
               WorkerList other = (WorkerList) obj;
               out.writeObject(other);
               out.close();
            }
            else
            {
               out.close();
               throw new IOException(
                     "You're trying to fit something different than a WorkerList into the Worker bin");
            }
         }
            break;

         case "Analysis.bin":
         {
            FileOutputStream fos = new FileOutputStream(file);
            ObjectOutputStream out = null;
            out = new ObjectOutputStream(fos);
            if (obj instanceof AnalysisList)
            {
               AnalysisList other = (AnalysisList) obj;
               out.writeObject(other);
               out.close();
            }
            else
            {
               out.close();
               throw new IOException(
                     "You're trying to fit something different than an AnalysisList into the Analysis bin");
            }
         }
            break;

         case "Schedule.bin":
         {
            FileOutputStream fos = new FileOutputStream(file);
            ObjectOutputStream out = null;
            out = new ObjectOutputStream(fos);
            if (obj instanceof TaskList)
            {
               TaskList other = (TaskList) obj;
               out.writeObject(other);
               out.close();
            }
            else
            {
               out.close();
               throw new IOException(
                     "You're trying to fit something different than a TaskList into the Master Schedule bin");
            }
         }
            break;

         case "TemplateS.bin":
         {
            FileOutputStream fos = new FileOutputStream(file);
            ObjectOutputStream out = null;
            out = new ObjectOutputStream(fos);
            if (obj instanceof TaskList)
            {
               TaskList other = (TaskList) obj;
               out.writeObject(other);
               out.close();
            }
            else
            {
               out.close();
               throw new IOException(
                     "You're trying to fit something different than a TaskList into the Small Template bin");
            }
         }
            break;

         case "TemplateL.bin":
         {
            FileOutputStream fos = new FileOutputStream(file);
            ObjectOutputStream out = null;
            out = new ObjectOutputStream(fos);
            if (obj instanceof TaskList)
            {
               TaskList other = (TaskList) obj;
               out.writeObject(other);
               out.close();
            }
            else
            {
               out.close();
               throw new IOException(
                     "You're trying to fit something different than a TaskList into the Large Template bin");
            }
         }
            break;

         default:
         {
            throw new IOException(
                  "The filename does not match with the bin files, please try again");
         }
      }
   }

   /**
    * Method that depending on the private variable filename loads the objects
    * from a file
    * 
    * @return Object The object/s being loaded from the file
    * @exception IOException
    *               The method throws this exception when the filename isn't
    *               spelled correctly
    * @exception ClassNotFoundException
    *               The method throws this exception when the object being read
    *               is unknown
    */

   public Object loadFromBin() throws IOException, ClassNotFoundException
   {
      switch (this.filename)
      {
         case "Workers.bin":
         {
            FileInputStream fis = new FileInputStream(file);
            ObjectInputStream in = null;
            in = new ObjectInputStream(fis);
            WorkerList worker = (WorkerList) in.readObject();
            in.close();
            return worker;
         }

         case "Analysis.bin":
         {
            FileInputStream fis = new FileInputStream(file);
            ObjectInputStream in = null;
            in = new ObjectInputStream(fis);
            AnalysisList analysis = (AnalysisList) in.readObject();
            in.close();
            return analysis;
         }

         case "Schedule.bin":
         {
            FileInputStream fis = new FileInputStream(file);
            ObjectInputStream in = null;
            in = new ObjectInputStream(fis);
            TaskList master = (TaskList) in.readObject();
            in.close();
            return master;
         }

         case "TemplateS.bin":
         {
            FileInputStream fis = new FileInputStream(file);
            ObjectInputStream in = null;
            in = new ObjectInputStream(fis);
            TaskList template = (TaskList) in.readObject();
            in.close();
            return template;
         }

         case "TemplateL.bin":
         {
            FileInputStream fis = new FileInputStream(file);
            ObjectInputStream in = null;
            in = new ObjectInputStream(fis);
            TaskList template = (TaskList) in.readObject();
            in.close();
            return template;
         }

         default:
         {
            throw new IOException(
                  "The filename does not match with the bin files, please try again");
         }
      }
   }

   /**
    * Method that loads objects from a text file then writes them to a specific
    * bin file
    * 
    * @exception IOException
    *               The method throws this exception when the filename isn't
    *               spelled correctly
    */

   public void loadWorkersFromTxt() throws IOException
   {
      WorkerList workers = new WorkerList();
      Scanner in = new Scanner(file);
      while (in.hasNext())
      {
         String line = in.nextLine();
         String[] token = line.split(";");
         workers.addWorker(new Worker(token[0].trim(), token[1].trim()));
      }
      in.close();
      File rFile = new File("Workers.bin");
      FileOutputStream fos = new FileOutputStream(rFile, true);
      ObjectOutputStream out = null;
      out = new ObjectOutputStream(fos);
      out.writeObject(workers);
      out.close();
   }
}
