package model;

public class Job
{

}
