package controller;


import model.Model;
import model.Worker;
import model.WorkerList;
import view.viewInterface;

public class Controller {
    public Model getModel() {
        return model;
    }

    public viewInterface getView() {
        return view;
    }

    private Model model;
    private viewInterface view;


    public Controller(Model model, viewInterface view) {
        this.model = model;
        this.view = view;
    }
}

