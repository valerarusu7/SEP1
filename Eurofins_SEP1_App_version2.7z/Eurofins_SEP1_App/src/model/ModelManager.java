package model;

public class ModelManager implements Model {

}
