package view;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import model.WorkerList;

public class AddWorkerViewController
{
   @FXML private TextField fullName;
   @FXML private TextField idWorker;
   @FXML private ResourceBundle resources;
   @FXML private URL location;
   private WorkerList list;
   private Scene scene;
   private GUI gui;

   public AddWorkerViewController(GUI gui) throws IOException {
      this.gui=gui;
      FXMLLoader loader = new FXMLLoader();
      loader.setLocation(getClass().getResource("AddWorker.fxml"));
      loader.setController(this);

      Parent root = loader.load();
      this.scene = new Scene(root);
   }

   public AddWorkerViewController(){
      this.list = new WorkerList();
   }

   public TextField getFullName() {
      return  fullName;
   }


   public TextField getIdWorker() {
      return idWorker;
   }

   public void initialize() {
   }

   public void ReturnbuttonPressed()  {
      gui.displayManageWorkersViewController();
   }

   public Scene getScene(){
      return scene;
   }

}
