package view;


import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


public class MainScheduleWorkerViewController  {

    private Scene scene;
   
   @FXML private ResourceBundle resources;
   @FXML private URL location;
   private GUI gui;

   @FXML void initialize() {
   }

   public MainScheduleWorkerViewController(GUI gui) throws IOException {
       this.gui=gui;
       FXMLLoader loader = new FXMLLoader();
       loader.setLocation(getClass().getResource("MainScheduleWorker.fxml"));
       loader.setController(this);

       Parent root = loader.load();
       this.scene = new Scene(root);
   }
   
  /* @FXML private void LogInButtonPressed() {
      gui.displayWindowLoginViewController();
   }*/

  public void SearchbuttonPressed() {
      gui.displaySearchViewController();
  }

  public void LogInButtonPressed() {
      gui.displayWindowLoginViewController();
  }

   public Scene getScene(){
      return scene;
   }
}