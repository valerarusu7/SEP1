package view;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import model.Worker;
import model.WorkerList;

public class WorkerListViewController {
    private AddWorkerViewController view;
    private Scene scene;
    private WorkerList lists;
    private GUI gui;
    @FXML private ResourceBundle resources;
    @FXML private TableView<Worker> tableView;
    @FXML private TableColumn<Worker, String> idColumn;
    @FXML private TableColumn<Worker, String> nameColumn;
    @FXML private URL location;

    public WorkerListViewController(GUI gui) throws IOException {
        this.gui=gui;
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("WorkerList.fxml"));
        loader.setController(this);

        Parent root = loader.load();
        this.scene = new Scene(root);
    }

    @FXML private void initialize() {
    }

    public void ReturnbuttonPressed()  {
        gui.displayManageWorkersViewController();
    }

    public Scene getScene(){
        return scene;
    }

}
