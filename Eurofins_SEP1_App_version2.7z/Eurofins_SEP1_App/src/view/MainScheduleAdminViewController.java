package view;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle; 
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class MainScheduleAdminViewController
{
   private GUI gui;
   private Scene scene;
   @FXML private ResourceBundle resources;
   @FXML private URL location;

   @FXML
   void initialize() {
   }

   public MainScheduleAdminViewController(GUI gui) throws IOException {
      this.gui=gui;
      FXMLLoader loader = new FXMLLoader();
      loader.setLocation(getClass().getResource("MainScheduleAdmin.fxml"));
      loader.setController(this);

      Parent root = loader.load();
      this.scene = new Scene(root);
   }


   public void signOutbuttonPressed()  {
      gui.displayMainScheduleWorkerViewController();
   }
   
   public void manageAnalysisbuttonPressed()  {
      gui.displayManageAnalysisViewController();
   }
   
   public void manageWorkersbuttonPressed()  {
      gui.displayManageWorkersViewController();
   }

   public void SearchbuttonPressed()  {
      gui.displaySearchViewController();
   }

   public Scene getScene(){
      return scene;
   }
}
