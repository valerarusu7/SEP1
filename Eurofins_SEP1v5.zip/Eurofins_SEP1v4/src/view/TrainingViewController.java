package view;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class TrainingViewController
{
   @FXML
   private ResourceBundle resources;
   @FXML
   private URL location;
   private GUI gui;
   private Scene scene;

   public TrainingViewController(GUI gui) throws IOException
   {
      this.gui = gui;
      FXMLLoader loader = new FXMLLoader();
      loader.setLocation(
            getClass().getResource("Training(Select analysis).fxml"));
      loader.setController(this);
      Parent root = loader.load();
      this.scene = new Scene(root);
   }

   @FXML
   void initialize()
   {

   }

   public Scene getScene()
   {
      return scene;
   }
}
