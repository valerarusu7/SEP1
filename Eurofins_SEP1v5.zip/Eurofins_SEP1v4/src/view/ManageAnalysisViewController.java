package view;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

public class ManageAnalysisViewController
{
   private GUI gui;
   private Scene scene;

   @FXML
   void initialize()
   {
   }

   public ManageAnalysisViewController(GUI gui) throws IOException
   {
      this.gui = gui;
      FXMLLoader loader = new FXMLLoader();
      loader.setLocation(getClass().getResource("Manage-Analysis.fxml"));
      loader.setController(this);

      Parent root = loader.load();
      this.scene = new Scene(root);
   }

   public void AddAnalysisbuttonPressed()
   {
      gui.displayAddAnalysisViewController();
   }

   public void RemoveAnalysisbuttonPressed()
   {
      gui.displayRemoveAnalysisViewController();
   }

   public void AnalysisListbuttonPressed()
   {
      gui.displayAnalysisListViewController();
   }

   public void ReturnbuttonPressed()
   {
      gui.displayMainScheduleAdminViewController();
   }

   public Scene getScene()
   {
      return scene;
   }
}
