package view;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import model.AnalysisList;

public class AddAnalysisViewController
{
   @FXML
   private TextField analysisName;
   @FXML
   private Label erroeLabel;
   private GUI gui;
   private Scene scene;
   private AnalysisList analysisList;

   public AddAnalysisViewController(GUI gui) throws IOException
   {
      this.gui = gui;
      FXMLLoader loader = new FXMLLoader();
      loader.setLocation(getClass().getResource("Add_Analysis.fxml"));
      loader.setController(this);
      Parent root = loader.load();
      this.scene = new Scene(root);
   }

   public AddAnalysisViewController()
   {
      this.analysisList = new AnalysisList();
   }

   public String getAnalysisName()
   {
      return analysisName.getText();
   }

   @FXML
   void initialize()
   {
      analysisName.setText("");
   }

   @FXML
   public void ReturnbuttonPressed()
   {
      gui.displayManageAnalysisViewController();
      analysisName.setText("");
   }

   public Scene getScene()
   {
      return scene;
   }

   @FXML
   private void addAnalysis()
   {
      gui.getController().createAnalysis();
      analysisName.setText("");
      gui.getController().getView().getAnalysisListViewController()
            .updateItems();
      gui.getController().getView().getRemoveAnalysisViewController()
            .updateItems();
      gui.getController().getView().displayAnalysisListViewController();
      gui.getController().getView().getAssignTaskViewController().updateItems();
   }
}
